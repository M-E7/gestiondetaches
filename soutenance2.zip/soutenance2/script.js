// Données de démonstration pour les tâches
const mockTasks = [
    {
        id: 1,
        title: "Préparer la présentation client",
        description: "Créer une présentation PowerPoint sur le nouveau projet de développement web pour le client XYZ",
        priority: "high",
        assignee: "Thomas Dupont",
        assigneeId: 1,
        dueDate: "2025-04-25",
        status: "to-do"
    },
    {
        id: 2,
        title: "Mise à jour du site web",
        description: "Mettre à jour la page d'accueil avec les nouvelles fonctionnalités et corriger les bugs signalés",
        priority: "medium",
        assignee: "Sophie Martin",
        assigneeId: 2,
        dueDate: "2025-04-22",
        status: "in-progress"
    },
    {
        id: 3,
        title: "Réunion d'équipe hebdomadaire",
        description: "Préparer l'ordre du jour et les rapports d'avancement pour la réunion d'équipe du vendredi",
        priority: "medium",
        assignee: "Pierre Lefebvre",
        assigneeId: 3,
        dueDate: "2025-04-19",
        status: "in-progress"
    },
    {
        id: 4,
        title: "Révision du code",
        description: "Examiner le code du module de paiement et suggérer des améliorations",
        priority: "high",
        assignee: "Marie Dubois",
        assigneeId: 4,
        dueDate: "2025-04-20",
        status: "to-do"
    },
    {
        id: 5,
        title: "Formation sur Bootstrap 5",
        description: "Suivre la formation en ligne sur les nouvelles fonctionnalités de Bootstrap 5",
        priority: "low",
        assignee: "Thomas Dupont",
        assigneeId: 1,
        dueDate: "2025-04-30",
        status: "to-do"
    },
    {
        id: 6,
        title: "Optimisation SEO",
        description: "Analyser et optimiser le référencement du site web pour améliorer son classement dans les moteurs de recherche",
        priority: "medium",
        assignee: "Sophie Martin",
        assigneeId: 2,
        dueDate: "2025-04-28",
        status: "completed"
    },
    {
        id: 7,
        title: "Correction de bugs",
        description: "Résoudre les problèmes signalés dans le système de suivi des bugs",
        priority: "high",
        assignee: "Pierre Lefebvre",
        assigneeId: 3,
        dueDate: "2025-04-18",
        status: "completed"
    }
];

// Stocker les tâches dans le localStorage pour la persistance
if (!localStorage.getItem('tasks')) {
    localStorage.setItem('tasks', JSON.stringify(mockTasks));
}

// Fonctions utilitaires
function formatDate(dateString) {
    const options = { day: '2-digit', month: '2-digit', year: 'numeric' };
    return new Date(dateString).toLocaleDateString('fr-FR', options);
}

function getPriorityClass(priority) {
    switch(priority) {
        case 'high': return 'priority-high';
        case 'medium': return 'priority-medium';
        case 'low': return 'priority-low';
        default: return '';
    }
}

function getStatusBadge(status) {
    switch(status) {
        case 'to-do': return '<span class="status-badge status-to-do">À faire</span>';
        case 'in-progress': return '<span class="status-badge status-in-progress">En cours</span>';
        case 'completed': return '<span class="status-badge status-completed">Terminée</span>';
        default: return '';
    }
}

function getPriorityIcon(priority) {
    switch(priority) {
        case 'high': return '<i class="fas fa-arrow-up text-danger"></i>';
        case 'medium': return '<i class="fas fa-minus text-warning"></i>';
        case 'low': return '<i class="fas fa-arrow-down text-info"></i>';
        default: return '';
    }
}

// Gestionnaire de tâches
class TaskManager {
    constructor() {
        this.tasks = JSON.parse(localStorage.getItem('tasks')) || [];
        this.init();
    }

    init() {
        this.renderTasks();
        this.updateTaskCounts();
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Filtrer les tâches par statut
        document.getElementById('statusFilter').addEventListener('change', () => {
            this.renderTasks();
        });

        // Rechercher des tâches
        document.getElementById('taskSearch').addEventListener('input', () => {
            this.renderTasks();
        });

        // Ajouter une nouvelle tâche
        document.getElementById('saveTaskBtn').addEventListener('click', () => {
            this.addTask();
        });
    }

    renderTasks() {
        const taskTableBody = document.getElementById('taskTableBody');
        const statusFilter = document.getElementById('statusFilter').value;
        const searchTerm = document.getElementById('taskSearch').value.toLowerCase();
        
        // Filtrer les tâches
        let filteredTasks = this.tasks;
        
        if (statusFilter !== 'all') {
            filteredTasks = filteredTasks.filter(task => task.status === statusFilter);
        }
        
        if (searchTerm) {
            filteredTasks = filteredTasks.filter(task => 
                task.title.toLowerCase().includes(searchTerm) || 
                task.description.toLowerCase().includes(searchTerm) ||
                task.assignee.toLowerCase().includes(searchTerm)
            );
        }
        
        // Trier les tâches (priorité, puis date d'échéance)
        filteredTasks.sort((a, b) => {
            const priorityOrder = { high: 1, medium: 2, low: 3 };
            if (a.status !== b.status) {
                const statusOrder = { 'to-do': 1, 'in-progress': 2, 'completed': 3 };
                return statusOrder[a.status] - statusOrder[b.status];
            }
            if (a.priority !== b.priority) {
                return priorityOrder[a.priority] - priorityOrder[b.priority];
            }
            return new Date(a.dueDate) - new Date(b.dueDate);
        });
        
        // Vider le tableau
        taskTableBody.innerHTML = '';
        
        // Ajouter les tâches au tableau
        filteredTasks.forEach(task => {
            const row = document.createElement('tr');
            row.dataset.taskId = task.id;
            row.className = task.status === 'completed' ? 'table-success' : '';
            
            row.innerHTML = `
                <td>${task.id}</td>
                <td>
                    <strong>${task.title}</strong>
                </td>
                <td>${task.description}</td>
                <td class="${getPriorityClass(task.priority)}">
                    ${getPriorityIcon(task.priority)} ${task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                </td>
                <td>
                    <div class="d-flex align-items-center">
                        <span class="avatar-initials me-2">${task.assignee.split(' ').map(n => n[0]).join('')}</span>
                        ${task.assignee}
                    </div>
                </td>
                <td>${formatDate(task.dueDate)}</td>
                <td>${getStatusBadge(task.status)}</td>
                <td>
                    <div class="btn-group">
                        <button class="btn btn-sm btn-outline-primary action-btn edit-task" title="Modifier">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger action-btn delete-task" title="Supprimer">
                            <i class="fas fa-trash"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-success action-btn progress-task" title="Changer le statut">
                            <i class="fas fa-chevron-right"></i>
                        </button>
                    </div>
                </td>
            `;
            
            taskTableBody.appendChild(row);
        });
        
        // Ajouter des événements pour les boutons d'action
        this.addActionButtonsEvents();
    }

    addActionButtonsEvents() {
        // Événement pour supprimer une tâche
        document.querySelectorAll('.delete-task').forEach(button => {
            button.addEventListener('click', (e) => {
                const taskId = parseInt(e.target.closest('tr').dataset.taskId);
                this.deleteTask(taskId);
            });
        });
        
        // Événement pour faire progresser le statut d'une tâche
        document.querySelectorAll('.progress-task').forEach(button => {
            button.addEventListener('click', (e) => {
                const taskId = parseInt(e.target.closest('tr').dataset.taskId);
                this.progressTaskStatus(taskId);
            });
        });
        
        // Événement pour éditer une tâche (à implémenter)
        document.querySelectorAll('.edit-task').forEach(button => {
            button.addEventListener('click', (e) => {
                const taskId = parseInt(e.target.closest('tr').dataset.taskId);
                this.editTask(taskId);
            });
        });
    }

    updateTaskCounts() {
        const toDoCount = this.tasks.filter(task => task.status === 'to-do').length;
        const inProgressCount = this.tasks.filter(task => task.status === 'in-progress').length;
        const completedCount = this.tasks.filter(task => task.status === 'completed').length;
        
        document.getElementById('toDoCount').textContent = toDoCount;
        document.getElementById('inProgressCount').textContent = inProgressCount;
        document.getElementById('completedCount').textContent = completedCount;
    }

    addTask() {
        const title = document.getElementById('taskTitle').value;
        const description = document.getElementById('taskDescription').value;
        const priority = document.getElementById('taskPriority').value;
        const status = document.getElementById('taskStatus').value;
        const dueDate = document.getElementById('taskDueDate').value;
        const assigneeSelect = document.getElementById('taskAssignee');
        const assigneeId = assigneeSelect.value;
        const assignee = assigneeSelect.options[assigneeSelect.selectedIndex].text;
        
        if (!title || !description || !dueDate || !assigneeId) {
            alert('Veuillez remplir tous les champs obligatoires.');
            return;
        }
        
        const newTask = {
            id: this.tasks.length > 0 ? Math.max(...this.tasks.map(task => task.id)) + 1 : 1,
            title,
            description,
            priority,
            assignee,
            assigneeId: parseInt(assigneeId),
            dueDate,
            status
        };
        
        this.tasks.push(newTask);
        this.saveTasks();
        this.renderTasks();
        this.updateTaskCounts();
        
        // Réinitialiser le formulaire et fermer le modal
        document.getElementById('addTaskForm').reset();
        const modal = bootstrap.Modal.getInstance(document.getElementById('addTaskModal'));
        modal.hide();
        
        // Animation de mise à jour
        setTimeout(() => {
            const newRow = document.querySelector(`tr[data-task-id="${newTask.id}"]`);
            if (newRow) {
                newRow.classList.add('status-change');
                setTimeout(() => {
                    newRow.classList.remove('status-change');
                }, 1000);
            }
        }, 100);
    }

    deleteTask(taskId) {
        if (confirm('Êtes-vous sûr de vouloir supprimer cette tâche ?')) {
            this.tasks = this.tasks.filter(task => task.id !== taskId);
            this.saveTasks();
            this.renderTasks();
            this.updateTaskCounts();
        }
    }

    progressTaskStatus(taskId) {
        const task = this.tasks.find(task => task.id === taskId);
        if (task) {
            switch (task.status) {
                case 'to-do':
                    task.status = 'in-progress';
                    break;
                case 'in-progress':
                    task.status = 'completed';
                    break;
                case 'completed':
                    task.status = 'to-do';
                    break;
            }
            
            this.saveTasks();
            this.renderTasks();
            this.updateTaskCounts();
            
            // Animation de mise à jour
            setTimeout(() => {
                const updatedRow = document.querySelector(`tr[data-task-id="${taskId}"]`);
                if (updatedRow) {
                    updatedRow.classList.add('status-change');
                    setTimeout(() => {
                        updatedRow.classList.remove('status-change');
                    }, 1000);
                }
            }, 100);
        }
    }

    editTask(taskId) {
        // Cette fonctionnalité pourrait être implémentée dans une version future
        alert(`Fonction d'édition pour la tâche ${taskId} sera disponible prochainement.`);
    }

    saveTasks() {
        localStorage.setItem('tasks', JSON.stringify(this.tasks));
    }
}

// Initialiser le gestionnaire de tâches lorsque le DOM est chargé
document.addEventListener('DOMContentLoaded', () => {
    const taskManager = new TaskManager();
    
    // Définir la date d'échéance minimale à aujourd'hui pour éviter les dates passées
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('taskDueDate').setAttribute('min', today);
    
    // Ajouter des exemples de statut visuel pour les priorités dans la légende
    addPriorityLegend();
    
    // Animation pour l'entrée des éléments lors du chargement
    animateElementsOnLoad();
});

// Ajouter une légende pour les priorités
function addPriorityLegend() {
    const legendHTML = `
        <div class="priority-legend mt-3 d-flex justify-content-end">
            <span class="me-3"><i class="fas fa-arrow-up text-danger"></i> Haute</span>
            <span class="me-3"><i class="fas fa-minus text-warning"></i> Moyenne</span>
            <span><i class="fas fa-arrow-down text-info"></i> Basse</span>
        </div>
    `;
    
    const taskListHeader = document.querySelector('.task-list .card-header');
    if (taskListHeader) {
        taskListHeader.insertAdjacentHTML('beforeend', legendHTML);
    }
}

// Animation pour l'entrée des éléments lors du chargement
function animateElementsOnLoad() {
    const dashboard = document.querySelector('.dashboard');
    const taskList = document.querySelector('.task-list');
    
    if (dashboard) {
        dashboard.style.opacity = '0';
        dashboard.style.transform = 'translateY(20px)';
        dashboard.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        
        setTimeout(() => {
            dashboard.style.opacity = '1';
            dashboard.style.transform = 'translateY(0)';
        }, 100);
    }
    
    if (taskList) {
        taskList.style.opacity = '0';
        taskList.style.transform = 'translateY(20px)';
        taskList.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        
        setTimeout(() => {
            taskList.style.opacity = '1';
            taskList.style.transform = 'translateY(0)';
        }, 300);
    }
}

// Gestion de l'état de visibilité des éléments (mobile)
function setupMobileResponsiveness() {
    const checkWindowSize = () => {
        if (window.innerWidth < 768) {
            // Ajuster pour les écrans mobiles
            document.querySelectorAll('.task-description').forEach(desc => {
                if (desc.textContent.length > 50) {
                    desc.setAttribute('data-full-text', desc.textContent);
                    desc.textContent = desc.textContent.substring(0, 50) + '...';
                    
                    desc.addEventListener('click', function() {
                        const fullText = this.getAttribute('data-full-text');
                        const isExpanded = this.getAttribute('data-expanded') === 'true';
                        
                        if (isExpanded) {
                            this.textContent = fullText.substring(0, 50) + '...';
                            this.setAttribute('data-expanded', 'false');
                        } else {
                            this.textContent = fullText;
                            this.setAttribute('data-expanded', 'true');
                        }
                    });
                }
            });
        }
    };
    
    // Vérifier la taille de la fenêtre au chargement
    checkWindowSize();
    
    // Vérifier à nouveau lors du redimensionnement
    window.addEventListener('resize', checkWindowSize);
}

// Mode nuit/jour
function setupDarkModeToggle() {
    // Ajouter un bouton pour le mode nuit/jour
    const header = document.querySelector('header .container');
    if (header) {
        const darkModeButton = document.createElement('button');
        darkModeButton.className = 'btn btn-outline-light position-absolute end-0 me-5';
        darkModeButton.innerHTML = '<i class="fas fa-moon"></i>';
        darkModeButton.id = 'darkModeToggle';
        darkModeButton.title = 'Basculer mode nuit/jour';
        header.style.position = 'relative';
        header.appendChild(darkModeButton);
        
        // Vérifier si le mode nuit est déjà activé
        const isDarkMode = localStorage.getItem('darkMode') === 'true';
        if (isDarkMode) {
            document.body.classList.add('dark-mode');
            darkModeButton.innerHTML = '<i class="fas fa-sun"></i>';
        }
        
        // Ajouter l'événement au bouton
        darkModeButton.addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            const isDark = document.body.classList.contains('dark-mode');
            localStorage.setItem('darkMode', isDark);
            darkModeButton.innerHTML = isDark ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
        });
    }
}

// Fonction pour exporter les tâches en format CSV
function exportTasksToCSV() {
    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    if (tasks.length === 0) {
        alert('Aucune tâche à exporter.');
        return;
    }
    
    // Créer l'en-tête CSV
    let csvContent = 'ID,Titre,Description,Priorité,Assigné à,Date d\'échéance,Statut\n';
    
    // Ajouter les données des tâches
    tasks.forEach(task => {
        // Échapper les virgules et guillemets dans les champs textuels
        const escapedTitle = `"${task.title.replace(/"/g, '""')}"`;
        const escapedDescription = `"${task.description.replace(/"/g, '""')}"`;
        
        csvContent += [
            task.id,
            escapedTitle,
            escapedDescription,
            task.priority,
            task.assignee,
            task.dueDate,
            task.status
        ].join(',') + '\n';
    });
    
    // Créer un blob et télécharger
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `taches_cat_entreprise_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Ajouter un bouton d'exportation CSV à l'interface
function addExportButton() {
    const dashboardHeader = document.querySelector('.dashboard .row.mb-4 .col-md-4');
    if (dashboardHeader) {
        const exportButton = document.createElement('button');
        exportButton.className = 'btn btn-outline-primary ms-2';
        exportButton.innerHTML = '<i class="fas fa-download"></i> Exporter CSV';
        exportButton.addEventListener('click', exportTasksToCSV);
        dashboardHeader.appendChild(exportButton);
    }
}

// Appeler ces fonctions après le chargement du DOM
document.addEventListener('DOMContentLoaded', () => {
    setupMobileResponsiveness();
    setupDarkModeToggle();
    addExportButton();
    
    // Vérifier s'il y a des tâches à échéance proche
    checkUpcomingDeadlines();
});

// Vérifier les échéances proches
function checkUpcomingDeadlines() {
    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    const today = new Date();
    const threeDaysLater = new Date();
    threeDaysLater.setDate(today.getDate() + 3);
    
    const upcomingTasks = tasks.filter(task => {
        if (task.status === 'completed') return false;
        const dueDate = new Date(task.dueDate);
        return dueDate >= today && dueDate <= threeDaysLater;
    });
    
    if (upcomingTasks.length > 0) {
        showNotification(`Vous avez ${upcomingTasks.length} tâche(s) avec une échéance dans les 3 prochains jours.`);
    }
}

// Afficher une notification
function showNotification(message) {
    const notificationContainer = document.createElement('div');
    notificationContainer.className = 'notification-container';
    notificationContainer.innerHTML = `
        <div class="notification-toast">
            <div class="toast-header">
                <strong class="me-auto"><i class="fas fa-bell text-warning"></i> Notification</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Fermer"></button>
            </div>
            <div class="toast-body">
                ${message}
            </div>
        </div>
    `;
    
    document.body.appendChild(notificationContainer);
    
    // Ajouter des styles pour la notification
    const style = document.createElement('style');
    style.textContent = `
        .notification-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1050;
        }
        .notification-toast {
            background: white;
            border-left: 4px solid var(--warning-color);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            width: 300px;
            padding: 15px;
            border-radius: 4px;
            animation: slideIn 0.5s forwards;
        }
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        .toast-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 8px;
        }
        .btn-close {
            background: transparent;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            padding: 0;
            line-height: 1;
        }
    `;
    document.head.appendChild(style);
    
    // Fermer la notification après 5 secondes
    setTimeout(() => {
        notificationContainer.style.animation = 'slideOut 0.5s forwards';
        setTimeout(() => {
            document.body.removeChild(notificationContainer);
        }, 500);
    }, 5000);
    
    // Ajouter un événement pour fermer manuellement
    notificationContainer.querySelector('.btn-close').addEventListener('click', () => {
        document.body.removeChild(notificationContainer);
    });
}

// Ajouter des styles pour le mode sombre
function addDarkModeStyles() {
    const darkModeStyles = document.createElement('style');
    darkModeStyles.textContent = `
        .dark-mode {
            background-color: #222;
            color: #eee;
        }
        .dark-mode .card {
            background-color: #333;
            color: #eee;
        }
        .dark-mode .table {
            color: #eee;
        }
        .dark-mode .table-light th {
            background-color: #444;
            color: #eee;
        }
        .dark-mode .modal-content {
            background-color: #333;
            color: #eee;
        }
        .dark-mode .form-control, .dark-mode .form-select {
            background-color: #444;
            color: #eee;
            border-color: #555;
        }
        .dark-mode .table-hover tbody tr:hover {
            background-color: #444;
        }
        .dark-mode .bg-light {
            background-color: #444 !important;
        }
        .dark-mode .text-dark {
            color: #eee !important;
        }
    `;
    document.head.appendChild(darkModeStyles);
}

// Appeler cette fonction pour ajouter les styles du mode sombre
document.addEventListener('DOMContentLoaded', addDarkModeStyles);