// Données des tâches (simule une base de données)
let tasks = [
  {
      id: 1,
      title: "Rédiger rapport mensuel",
      description: "Préparer le rapport d'activité du mois d'avril",
      creationDate: "2025-04-15",
      dueDate: "2025-04-20",
      priority: "high",
      status: "inProgress",
      requiresValidation: true,
      attachmentName: null
  },
  {
      id: 2,
      title: "Organiser réunion d'équipe",
      description: "Planifier l'ordre du jour et envoyer les invitations",
      creationDate: "2025-04-16",
      dueDate: "2025-04-19",
      priority: "medium",
      status: "pending",
      requiresValidation: false,
      attachmentName: null
  },
  {
      id: 3,
      title: "Réviser la documentation",
      description: "Mettre à jour la documentation technique du projet Alpha",
      creationDate: "2025-04-10",
      dueDate: "2025-04-17",
      priority: "low",
      status: "completed",
      requiresValidation: false,
      attachmentName: null
  },
  {
      id: 4,
      title: "Soumettre factures",
      description: "Envoyer les factures du mois dernier au service comptable",
      creationDate: "2025-04-14",
      dueDate: "2025-04-18",
      priority: "high",
      status: "validation",
      requiresValidation: true,
      attachmentName: "factures-mars.pdf"
  }
];

// Éléments DOM
const taskList = document.getElementById('taskList');
const addTaskBtn = document.getElementById('addTaskBtn');
const saveTaskBtn = document.getElementById('saveTaskBtn');
const editTaskBtn = document.getElementById('editTaskBtn');
const taskForm = document.getElementById('taskForm');
const requiresValidationCheckbox = document.getElementById('requiresValidation');
const fileUploadContainer = document.getElementById('fileUploadContainer');

// Filtres et tris
const statusFilter = document.getElementById('statusFilter');
const priorityFilter = document.getElementById('priorityFilter');
const validationFilter = document.getElementById('validationFilter');
const sortBy = document.getElementById('sortBy');

// Bootstrap Modals
const taskModal = new bootstrap.Modal(document.getElementById('taskModal'));
const taskDetailModal = new bootstrap.Modal(document.getElementById('taskDetailModal'));

// Écouteurs d'événements
document.addEventListener('DOMContentLoaded', () => {
  // Afficher la liste des tâches initiale
  renderTaskList();
  
  // Écouteurs pour les filtres et tris
  statusFilter.addEventListener('change', renderTaskList);
  priorityFilter.addEventListener('change', renderTaskList);
  validationFilter.addEventListener('change', renderTaskList);
  sortBy.addEventListener('change', renderTaskList);
  
  // Écouteur pour le bouton d'ajout de tâche
  addTaskBtn.addEventListener('click', () => {
      clearTaskForm();
      document.getElementById('taskModalLabel').textContent = 'Nouvelle tâche';
      taskModal.show();
  });
  
  // Écouteur pour la soumission du formulaire de tâche
  saveTaskBtn.addEventListener('click', saveTask);
  
  // Écouteur pour l'option de validation documentaire
  requiresValidationCheckbox.addEventListener('change', () => {
      fileUploadContainer.style.display = requiresValidationCheckbox.checked ? 'block' : 'none';
  });
});

// Fonctions pour la gestion des tâches

// Afficher la liste des tâches
function renderTaskList() {
  // Filtrage
  let filteredTasks = tasks.filter(task => {
      // Filtre par statut
      if (statusFilter.value !== 'all' && task.status !== statusFilter.value) {
          return false;
      }
      
      // Filtre par priorité
      if (priorityFilter.value !== 'all' && task.priority !== priorityFilter.value) {
          return false;
      }
      
      // Filtre par type de validation
      if (validationFilter.value === 'withDoc' && !task.requiresValidation) {
          return false;
      }
      if (validationFilter.value === 'withoutDoc' && task.requiresValidation) {
          return false;
      }
      
      return true;
  });
  
  // Tri
  filteredTasks.sort((a, b) => {
      switch (sortBy.value) {
          case 'dueDate':
              return new Date(a.dueDate) - new Date(b.dueDate);
          case 'priority':
              const priorityOrder = { high: 0, medium: 1, low: 2 };
              return priorityOrder[a.priority] - priorityOrder[b.priority];
          case 'creationDate':
              return new Date(a.creationDate) - new Date(b.creationDate);
          case 'title':
              return a.title.localeCompare(b.title);
          default:
              return 0;
      }
  });
  
  // Vider la liste actuelle
  taskList.innerHTML = '';
  
  // Ajout de chaque tâche à la liste
  if (filteredTasks.length === 0) {
      taskList.innerHTML = `
          <li class="list-group-item text-center py-4">
              <p class="text-muted mb-0">Aucune tâche ne correspond à vos critères</p>
          </li>
      `;
  } else {
      filteredTasks.forEach(task => {
          const taskItem = document.createElement('li');
          taskItem.className = `list-group-item task-item priority-${task.priority}`;
          taskItem.dataset.id = task.id;
          
          // Vérifier si la date d'échéance est dépassée ou proche
          const today = new Date();
          const dueDate = new Date(task.dueDate);
          const timeDiff = dueDate - today;
          const daysDiff = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
          
          let dueDateClass = '';
          if (daysDiff < 0) {
              dueDateClass = 'overdue';
          } else if (daysDiff <= 2) {
              dueDateClass = 'due-soon';
          }
          
          // Format de la date d'échéance
          const formattedDueDate = dueDate.toLocaleDateString('fr-FR', { 
              day: '2-digit', 
              month: '2-digit', 
              year: 'numeric' 
          });
          
          // Indicateurs d'état
          const statusLabels = {
              pending: 'En attente',
              inProgress: 'En cours',
              validation: 'En validation',
              completed: 'Terminé'
          };
          
          // Actions disponibles selon l'état
          let actions = '';
          
          switch(task.status) {
              case 'pending':
                  actions = `
                      <button class="btn btn-sm btn-outline-primary start-task-btn" data-id="${task.id}">
                          <i class="fas fa-play me-1"></i>Mettre en cours
                      </button>
                  `;
                  break;
              case 'inProgress':
                  if (task.requiresValidation) {
                      actions = `
                          <button class="btn btn-sm btn-outline-purple submit-task-btn" data-id="${task.id}">
                              <i class="fas fa-file-upload me-1"></i>Soumettre pour validation
                          </button>
                      `;
                  } else {
                      actions = `
                          <button class="btn btn-sm btn-outline-success complete-task-btn" data-id="${task.id}">
                              <i class="fas fa-check me-1"></i>Terminer
                          </button>
                      `;
                  }
                  actions += `
                      <button class="btn btn-sm btn-outline-secondary ms-2 pause-task-btn" data-id="${task.id}">
                          <i class="fas fa-pause me-1"></i>Mettre en attente
                      </button>
                  `;
                  break;
              case 'validation':
                  // Aucune action directe pour les tâches en validation
                  actions = `
                      <span class="text-muted fst-italic">En attente de validation</span>
                  `;
                  break;
              case 'completed':
                  actions = `
                      <span class="text-success"><i class="fas fa-check-circle me-1"></i>Tâche terminée</span>
                  `;
                  break;
          }
          
          // Icônes de validation documentaire
          let validationIcon = '';
          if (task.requiresValidation) {
              validationIcon = task.attachmentName 
                  ? `<i class="fas fa-paperclip ms-2" title="Pièce jointe: ${task.attachmentName}"></i>`
                  : `<i class="fas fa-file-upload ms-2" title="Document requis"></i>`;
          }
          
          taskItem.innerHTML = `
              <div class="d-flex justify-content-between align-items-start">
                  <div class="task-info cursor-pointer" onclick="showTaskDetails(${task.id})">
                      <div class="d-flex align-items-center mb-1">
                          <h5 class="mb-0">${task.title}</h5>
                          <span class="badge status-badge status-${task.status} ms-2">${statusLabels[task.status]}</span>
                          ${validationIcon}
                      </div>
                      <div class="task-icons small">
                          <span class="due-date ${dueDateClass}">
                              <i class="far fa-calendar-alt"></i> Échéance: ${formattedDueDate}
                          </span>
                          <span class="ms-3">
                              <i class="fas fa-signal"></i> ${getPriorityLabel(task.priority)}
                          </span>
                      </div>
                  </div>
                  <div class="task-actions">
                      ${actions}
                  </div>
              </div>
          `;
          
          taskList.appendChild(taskItem);
      });
      
      // Ajouter des écouteurs pour les boutons d'action
      document.querySelectorAll('.start-task-btn').forEach(btn => {
          btn.addEventListener('click', (e) => updateTaskStatus(e, 'inProgress'));
      });
      
      document.querySelectorAll('.pause-task-btn').forEach(btn => {
          btn.addEventListener('click', (e) => updateTaskStatus(e, 'pending'));
      });
      
      document.querySelectorAll('.complete-task-btn').forEach(btn => {
          btn.addEventListener('click', (e) => updateTaskStatus(e, 'completed'));
      });
      
      document.querySelectorAll('.submit-task-btn').forEach(btn => {
          btn.addEventListener('click', (e) => {
              const taskId = parseInt(e.currentTarget.dataset.id);
              prepareForValidation(taskId);
          });
      });
  }
}

// Obtenir le libellé de priorité
function getPriorityLabel(priority) {
  switch(priority) {
      case 'high': return 'Priorité haute';
      case 'medium': return 'Priorité moyenne';
      case 'low': return 'Priorité basse';
      default: return 'Non définie';
  }
}

// Mettre à jour le statut d'une tâche
function updateTaskStatus(event, newStatus) {
  event.stopPropagation();
  const taskId = parseInt(event.currentTarget.dataset.id);
  const taskIndex = tasks.findIndex(task => task.id === taskId);
  
  if (taskIndex !== -1) {
      tasks[taskIndex].status = newStatus;
      
      // Animer le changement
      const taskItem = event.currentTarget.closest('.task-item');
      taskItem.classList.add('highlight');
      
      // Mettre à jour l'interface
      renderTaskList();
  }
}

// Préparer la tâche pour la validation
function prepareForValidation(taskId) {
  const task = tasks.find(task => task.id === taskId);
  
  if (task) {
      // Si la tâche a déjà une pièce jointe, la mettre directement en validation
      if (task.attachmentName) {
          task.status = 'validation';
          renderTaskList();
      } else {
          // Sinon, ouvrir une boîte de dialogue pour télécharger la pièce jointe
          document.getElementById('taskModalLabel').textContent = 'Soumettre pour validation';
          
          // Préremplir le formulaire
          document.getElementById('taskId').value = task.id;
          document.getElementById('taskTitle').value = task.title;
          document.getElementById('taskTitle').disabled = true;
          document.getElementById('taskDescription').value = task.description;
          document.getElementById('taskDescription').disabled = true;
          document.getElementById('taskDueDate').value = task.dueDate;
          document.getElementById('taskDueDate').disabled = true;
          document.getElementById('taskPriority').value = task.priority;
          document.getElementById('taskPriority').disabled = true;
          document.getElementById('requiresValidation').checked = true;
          document.getElementById('requiresValidation').disabled = true;
          
          // Afficher la zone de téléchargement de fichier
          fileUploadContainer.style.display = 'block';
          document.getElementById('taskFile').setAttribute('required', 'required');
          
          // Changer le texte du bouton de sauvegarde
          saveTaskBtn.textContent = 'Soumettre';
          saveTaskBtn.onclick = () => {
              const fileInput = document.getElementById('taskFile');
              if (fileInput.files.length > 0) {
                  task.attachmentName = fileInput.files[0].name;
                  task.status = 'validation';
                  renderTaskList();
                  taskModal.hide();
              } else {
                  alert('Veuillez sélectionner un fichier à joindre');
              }
          };
          
          taskModal.show();
      }
  }
}

// Afficher les détails d'une tâche
function showTaskDetails(taskId) {
  const task = tasks.find(task => task.id === taskId);
  
  if (task) {
      const taskDetailContent = document.getElementById('taskDetailContent');
      const formattedCreationDate = new Date(task.creationDate).toLocaleDateString('fr-FR');
      const formattedDueDate = new Date(task.dueDate).toLocaleDateString('fr-FR');
      
      // Statut
      const statusLabels = {
          pending: 'En attente',
          inProgress: 'En cours',
          validation: 'En validation',
          completed: 'Terminé'
      };
      
      // Priorité
      const priorityLabels = {
          high: 'Haute',
          medium: 'Moyenne',
          low: 'Basse'
      };
      
      // Information sur la pièce jointe
      let attachmentInfo = 'Non requis';
      if (task.requiresValidation) {
          attachmentInfo = task.attachmentName 
              ? `<strong>Pièce jointe:</strong> ${task.attachmentName}` 
              : '<span class="text-warning">Document requis, non fourni</span>';
      }
      
      taskDetailContent.innerHTML = `
          <h4>${task.title}</h4>
          <div class="badge bg-${task.status === 'completed' ? 'success' : task.status === 'validation' ? 'purple' : task.status === 'inProgress' ? 'primary' : 'secondary'} mb-3">
              ${statusLabels[task.status]}
          </div>
          
          <div class="mb-3">
              <strong>Description:</strong>
              <p>${task.description || 'Aucune description fournie'}</p>
          </div>
          
          <div class="row mb-2">
              <div class="col-md-6">
                  <strong>Date de création:</strong> ${formattedCreationDate}
              </div>
              <div class="col-md-6">
                  <strong>Date d'échéance:</strong> ${formattedDueDate}
              </div>
          </div>
          
          <div class="row mb-3">
              <div class="col-md-6">
                  <strong>Priorité:</strong> ${priorityLabels[task.priority]}
              </div>
              <div class="col-md-6">
                  <strong>Validation documentaire:</strong> ${task.requiresValidation ? 'Oui' : 'Non'}
              </div>
          </div>
          
          <div class="mb-3">
              ${task.requiresValidation ? attachmentInfo : ''}
          </div>
      `;
      
      // Configurer le bouton d'édition
      const editTaskBtn = document.getElementById('editTaskBtn');
      editTaskBtn.onclick = () => {
          prepareEditTask(task.id);
          taskDetailModal.hide();
      };
      
      // Si la tâche est terminée, masquer le bouton d'édition
      editTaskBtn.style.display = task.status === 'completed' ? 'none' : 'block';
      
      taskDetailModal.show();
  }
}

// Préparer l'édition d'une tâche
function prepareEditTask(taskId) {
  const task = tasks.find(task => task.id === taskId);
  
  if (task) {
      document.getElementById('taskModalLabel').textContent = 'Modifier la tâche';
      
      // Remplir le formulaire
      document.getElementById('taskId').value = task.id;
      document.getElementById('taskTitle').value = task.title;
      document.getElementById('taskTitle').disabled = false;
      document.getElementById('taskDescription').value = task.description;
      document.getElementById('taskDescription').disabled = false;
      document.getElementById('taskDueDate').value = task.dueDate;
      document.getElementById('taskDueDate').disabled = false;
      document.getElementById('taskPriority').value = task.priority;
      document.getElementById('taskPriority').disabled = false;
      document.getElementById('requiresValidation').checked = task.requiresValidation;
      document.getElementById('requiresValidation').disabledocument.getElementById('requiresValidation').disabled = task.status === 'validation';
        
      // Afficher/masquer la zone de téléchargement de fichier
      fileUploadContainer.style.display = task.requiresValidation ? 'block' : 'none';
      document.getElementById('taskFile').removeAttribute('required');
      
      // Restaurer le comportement par défaut du bouton de sauvegarde
      saveTaskBtn.textContent = 'Enregistrer';
      saveTaskBtn.onclick = saveTask;
      
      taskModal.show();
  }
}

// Vider le formulaire de tâche
function clearTaskForm() {
  document.getElementById('taskId').value = '';
  document.getElementById('taskTitle').value = '';
  document.getElementById('taskTitle').disabled = false;
  document.getElementById('taskDescription').value = '';
  document.getElementById('taskDescription').disabled = false;
  document.getElementById('taskDueDate').value = '';
  document.getElementById('taskDueDate').disabled = false;
  document.getElementById('taskPriority').value = 'medium';
  document.getElementById('taskPriority').disabled = false;
  document.getElementById('requiresValidation').checked = false;
  document.getElementById('requiresValidation').disabled = false;
  fileUploadContainer.style.display = 'none';
  document.getElementById('taskFile').value = '';
  document.getElementById('taskFile').removeAttribute('required');
  
  // Restaurer le comportement par défaut du bouton de sauvegarde
  saveTaskBtn.textContent = 'Enregistrer';
  saveTaskBtn.onclick = saveTask;
}

// Sauvegarder une tâche (nouvelle ou existante)
function saveTask() {
  const taskId = document.getElementById('taskId').value;
  const title = document.getElementById('taskTitle').value.trim();
  const description = document.getElementById('taskDescription').value.trim();
  const dueDate = document.getElementById('taskDueDate').value;
  const priority = document.getElementById('taskPriority').value;
  const requiresValidation = document.getElementById('requiresValidation').checked;
  const fileInput = document.getElementById('taskFile');
  
  // Validation basique
  if (!title) {
      alert('Le titre de la tâche est obligatoire.');
      return;
  }
  
  const today = new Date().toISOString().split('T')[0];
  
  // Mise à jour ou création de tâche
  if (taskId) {
      // Mise à jour d'une tâche existante
      const taskIndex = tasks.findIndex(task => task.id === parseInt(taskId));
      if (taskIndex !== -1) {
          // Préserver le statut et la pièce jointe existante
          const currentStatus = tasks[taskIndex].status;
          let attachmentName = tasks[taskIndex].attachmentName;
          
          // Mettre à jour la pièce jointe si un fichier est sélectionné
          if (fileInput.files.length > 0) {
              attachmentName = fileInput.files[0].name;
          }
          
          tasks[taskIndex] = {
              ...tasks[taskIndex],
              title,
              description,
              dueDate,
              priority,
              requiresValidation,
              attachmentName
          };
      }
  } else {
      // Création d'une nouvelle tâche
      let attachmentName = null;
      if (requiresValidation && fileInput.files.length > 0) {
          attachmentName = fileInput.files[0].name;
      }
      
      const newTask = {
          id: tasks.length > 0 ? Math.max(...tasks.map(task => task.id)) + 1 : 1,
          title,
          description,
          creationDate: today,
          dueDate,
          priority,
          status: 'pending',
          requiresValidation,
          attachmentName
      };
      
      tasks.push(newTask);
  }
  
  // Fermer le modal et mettre à jour l'interface
  taskModal.hide();
  renderTaskList();
}

// Rechercher des tâches
function searchTasks(query) {
  query = query.toLowerCase().trim();
  
  if (!query) {
      renderTaskList();
      return;
  }
  
  const filteredTasks = tasks.filter(task => {
      return (
          task.title.toLowerCase().includes(query) ||
          (task.description && task.description.toLowerCase().includes(query))
      );
  });
  
  // Remplacer temporairement les tâches et les afficher
  const originalTasks = [...tasks];
  tasks = filteredTasks;
  renderTaskList();
  tasks = originalTasks;
}

// Exportation des tâches au format JSON
function exportTasks() {
  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(tasks, null, 2));
  const downloadAnchorNode = document.createElement('a');
  downloadAnchorNode.setAttribute("href", dataStr);
  downloadAnchorNode.setAttribute("download", "cat_entreprise_tasks.json");
  document.body.appendChild(downloadAnchorNode);
  downloadAnchorNode.click();
  downloadAnchorNode.remove();
}

// Importation des tâches depuis un fichier JSON
function importTasks(event) {
  const fileInput = event.target;
  const file = fileInput.files[0];
  
  if (file) {
      const reader = new FileReader();
      reader.onload = function(e) {
          try {
              const importedTasks = JSON.parse(e.target.result);
              
              // Validation basique
              if (Array.isArray(importedTasks) && importedTasks.length > 0) {
                  // Confirmer l'importation
                  if (confirm(`Importer ${importedTasks.length} tâches ? Cela remplacera vos tâches actuelles.`)) {
                      tasks = importedTasks;
                      renderTaskList();
                  }
              } else {
                  alert("Le fichier importé ne semble pas contenir des tâches valides.");
              }
          } catch (error) {
              alert("Erreur lors de l'importation du fichier : " + error.message);
          }
      };
      reader.readAsText(file);
  }
  
  // Réinitialiser l'input file pour permettre l'importation du même fichier
  fileInput.value = '';
}

// Ajout de fonctions pour les statistiques et rapports

// Calculer les statistiques des tâches
function getTaskStats() {
  // Compter les tâches par statut
  const statusCounts = {
      pending: 0,
      inProgress: 0,
      validation: 0,
      completed: 0
  };
  
  // Compter les tâches par priorité
  const priorityCounts = {
      high: 0,
      medium: 0,
      low: 0
  };
  
  // Compter les tâches en retard
  let overdueTasks = 0;
  const today = new Date();
  
  tasks.forEach(task => {
      // Compter par statut
      statusCounts[task.status]++;
      
      // Compter par priorité
      priorityCounts[task.priority]++;
      
      // Vérifier si la tâche est en retard
      const dueDate = new Date(task.dueDate);
      if (dueDate < today && task.status !== 'completed') {
          overdueTasks++;
      }
  });
  
  // Calculer les pourcentages de complétion
  const totalTasks = tasks.length;
  const completionRate = totalTasks > 0 ? (statusCounts.completed / totalTasks * 100).toFixed(1) : 0;
  
  return {
      total: totalTasks,
      statusCounts,
      priorityCounts,
      overdueTasks,
      completionRate
  };
}

// Afficher un tableau de bord des tâches
function showDashboard() {
  const stats = getTaskStats();
  
  // Créer et montrer une modale pour le tableau de bord
  const dashboardHTML = `
      <div class="modal fade" id="dashboardModal" tabindex="-1" aria-labelledby="dashboardModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg">
              <div class="modal-content">
                  <div class="modal-header">
                      <h5 class="modal-title" id="dashboardModalLabel">Tableau de bord des tâches</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                  </div>
                  <div class="modal-body">
                      <div class="row mb-4">
                          <div class="col-md-6">
                              <div class="card h-100">
                                  <div class="card-body">
                                      <h5 class="card-title">Résumé</h5>
                                      <p>Nombre total de tâches: <strong>${stats.total}</strong></p>
                                      <p>Taux de complétion: <strong>${stats.completionRate}%</strong></p>
                                      <p>Tâches en retard: <strong>${stats.overdueTasks}</strong></p>
                                  </div>
                              </div>
                          </div>
                          <div class="col-md-6">
                              <div class="card h-100">
                                  <div class="card-body">
                                      <h5 class="card-title">Par priorité</h5>
                                      <p>Haute: <strong>${stats.priorityCounts.high}</strong></p>
                                      <p>Moyenne: <strong>${stats.priorityCounts.medium}</strong></p>
                                      <p>Basse: <strong>${stats.priorityCounts.low}</strong></p>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="row">
                          <div class="col-12">
                              <div class="card">
                                  <div class="card-body">
                                      <h5 class="card-title">Par statut</h5>
                                      <div class="progress" style="height: 30px;">
                                          <div class="progress-bar bg-secondary" style="width: ${stats.total > 0 ? (stats.statusCounts.pending / stats.total * 100) : 0}%" title="En attente">
                                              ${stats.statusCounts.pending}
                                          </div>
                                          <div class="progress-bar bg-primary" style="width: ${stats.total > 0 ? (stats.statusCounts.inProgress / stats.total * 100) : 0}%" title="En cours">
                                              ${stats.statusCounts.inProgress}
                                          </div>
                                          <div class="progress-bar bg-purple" style="width: ${stats.total > 0 ? (stats.statusCounts.validation / stats.total * 100) : 0}%" title="En validation">
                                              ${stats.statusCounts.validation}
                                          </div>
                                          <div class="progress-bar bg-success" style="width: ${stats.total > 0 ? (stats.statusCounts.completed / stats.total * 100) : 0}%" title="Terminé">
                                              ${stats.statusCounts.completed}
                                          </div>
                                      </div>
                                      <div class="mt-3 d-flex justify-content-between">
                                          <span>En attente: <strong>${stats.statusCounts.pending}</strong></span>
                                          <span>En cours: <strong>${stats.statusCounts.inProgress}</strong></span>
                                          <span>En validation: <strong>${stats.statusCounts.validation}</strong></span>
                                          <span>Terminé: <strong>${stats.statusCounts.completed}</strong></span>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                      
                      <div class="mt-4">
                          <h5>Actions</h5>
                          <button class="btn btn-outline-success" onclick="exportTasks()">
                              <i class="fas fa-file-export me-1"></i>Exporter les tâches
                          </button>
                          <label class="btn btn-outline-primary ms-2">
                              <i class="fas fa-file-import me-1"></i>Importer des tâches
                              <input type="file" id="importTasksInput" accept=".json" style="display: none;" onchange="importTasks(event)">
                          </label>
                      </div>
                  </div>
                  <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                  </div>
              </div>
          </div>
      </div>
  `;
  
  // Ajouter la modale au corps du document
  const tempDiv = document.createElement('div');
  tempDiv.innerHTML = dashboardHTML;
  document.body.appendChild(tempDiv.firstElementChild);
  
  // Afficher la modale
  const dashboardModal = new bootstrap.Modal(document.getElementById('dashboardModal'));
  dashboardModal.show();
  
  // Nettoyer la modale quand elle est fermée
  document.getElementById('dashboardModal').addEventListener('hidden.bs.modal', function() {
      this.remove();
  });
}

// Ajouter un bouton pour le tableau de bord
document.addEventListener('DOMContentLoaded', () => {
  // Créer un bouton de tableau de bord dans l'en-tête
  const headerContainer = document.querySelector('header .container .d-flex');
  
  const dashboardButton = document.createElement('button');
  dashboardButton.className = 'btn btn-info ms-2';
  dashboardButton.innerHTML = '<i class="fas fa-chart-bar me-1"></i>Tableau de bord';
  dashboardButton.addEventListener('click', showDashboard);
  
  document.querySelector('header .container .d-flex div:last-child').appendChild(dashboardButton);
});

// Fonctionnalité de recherche
document.addEventListener('DOMContentLoaded', () => {
  // Ajouter un champ de recherche
  const filterRow = document.querySelector('.card-body .row');
  
  const searchCol = document.createElement('div');
  searchCol.className = 'col-12 mt-3';
  searchCol.innerHTML = `
      <div class="input-group">
          <span class="input-group-text"><i class="fas fa-search"></i></span>
          <input type="text" class="form-control" id="searchTasks" placeholder="Rechercher des tâches...">
          <button class="btn btn-outline-secondary" type="button" id="clearSearch">Effacer</button>
      </div>
  `;
  
  filterRow.after(searchCol);
  
  // Ajouter des écouteurs d'événements pour la recherche
  const searchInput = document.getElementById('searchTasks');
  searchInput.addEventListener('input', () => {
      searchTasks(searchInput.value);
  });
  
  document.getElementById('clearSearch').addEventListener('click', () => {
      searchInput.value = '';
      renderTaskList();
  });
});