$(document).ready(function() {
    const loginSection = $('#login-section');
    const registerSection = $('#register-section');
    const dashboardSection = $('#dashboard-section');
    const loginForm = $('#login-form');
    const registerForm = $('#register-form');
    const showRegisterFormLink = $('#show-register-form');
    const showLoginFormLink = $('#show-login-form');
    const logoutBtn = $('#logout-btn');
    const requestsList = $('#requests-list');
    const userNameDisplay = $('#user-name');
    const loginError = $('#login-error');
    const registerError = $('#register-error');

    // Fonction pour afficher le tableau de bord et les demandes
    function showDashboard(userData) {
        loginSection.addClass('d-none');
        registerSection.addClass('d-none');
        dashboardSection.removeClass('d-none');
        userNameDisplay.text(userData.name || userData.email); // Afficher le nom si disponible

        // Simuler la récupération des demandes depuis le serveur (à remplacer par un appel API réel)
        const userRequests = getRequestsForUser(userData.email);
        displayRequests(userRequests);
    }

    // Fonction pour afficher les demandes dans le tableau de bord
    function displayRequests(requests) {
        requestsList.empty();
        if (requests && requests.length > 0) {
            requests.forEach(request => {
                const requestItem = $('<div class="request-item"></div>');
                requestItem.append(`<p><strong>ID de Demande:</strong> ${request.id}</p>`);
                requestItem.append(`<p><strong>Date de Soumission:</strong> ${request.submissionDate}</p>`);
                requestItem.append(`<p><strong>Statut:</strong> <span class="status-indicator status-${request.status.toLowerCase().replace(' ', '-')}">${request.status}</span></p>`);
                requestsList.append(requestItem);
            });
        } else {
            requestsList.append('<p>Aucune demande enregistrée pour le moment.</p>');
        }
    }

    // Simuler la récupération des demandes pour un utilisateur (à remplacer par un appel API réel)
    function getRequestsForUser(email) {
        // Ici, vous feriez un appel à votre backend pour récupérer les demandes de cet utilisateur.
        // Pour la simulation, nous allons retourner des données statiques basées sur l'email.
        if (email === 'client1@example.com') {
            return [
                { id: 'DEM2025-001', submissionDate: '2025-04-10', status: 'Reçue' },
                { id: 'DEM2025-003', submissionDate: '2025-04-15', status: 'En cours d\'analyse' }
            ];
        } else if (email === 'client2@example.com') {
            return [
                { id: 'DEM2025-002', submissionDate: '2025-04-12', status: 'Terminée' }
            ];
        }
        return [];
    }

    // Gestion de la soumission du formulaire de connexion
    loginForm.on('submit', function(event) {
        event.preventDefault();
        const email = $('#login-email').val();
        const password = $('#login-password').val();

        // Simuler l'authentification (à remplacer par un appel API réel)
        if (email === 'client1@example.com' && password === 'pass123') {
            const userData = { email: email, name: 'Client Un' };
            localStorage.setItem('user', JSON.stringify(userData));
            showDashboard(userData);
            loginError.addClass('d-none');
        } else if (email === 'client2@example.com' && password === 'secure456') {
            const userData = { email: email };
            localStorage.setItem('user', JSON.stringify(userData));
            showDashboard(userData);
            loginError.addClass('d-none');
        } else {
            loginError.removeClass('d-none');
        }
    });

    // Gestion de la soumission du formulaire d'inscription
    registerForm.on('submit', function(event) {
        event.preventDefault();
        const name = $('#register-name').val();
        const email = $('#register-email').val();
        const password = $('#register-password').val();

        // Simuler l'enregistrement (à remplacer par un appel API réel)
        // Ici, vous enverriez ces données à votre backend pour créer un nouvel utilisateur.
        console.log('Tentative d\'enregistrement:', name, email, password);
        // En cas de succès (simulé ici), connectez l'utilisateur et affichez le tableau de bord.
        const registrationSuccessful = true; // Remplacez par la logique réelle
        if (registrationSuccessful) {
            const userData = { name: name, email: email };
            localStorage.setItem('user', JSON.stringify(userData));
            showDashboard(userData);
            registerError.addClass('d-none');
        } else {
            registerError.removeClass('d-none');
            registerError.text('Erreur lors de la création du compte. Veuillez réessayer.');
        }
    });

    // Afficher le formulaire d'inscription
    showRegisterFormLink.on('click', function(event) {
        event.preventDefault();
        loginSection.addClass('d-none');
        registerSection.removeClass('d-none');
        loginError.addClass('d-none');
    });

    // Afficher le formulaire de connexion
    showLoginFormLink.on('click', function(event) {
        event.preventDefault();
        registerSection.addClass('d-none');
        loginSection.removeClass('d-none');
        registerError.addClass('d-none');
    });

    // Gestion de la déconnexion
    logoutBtn.on('click', function() {
        localStorage.removeItem('user');
        dashboardSection.addClass('d-none');
        loginSection.removeClass('d-none');
    });

    // Vérifier si l'utilisateur est déjà connecté au chargement de la page
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
        showDashboard(JSON.parse(storedUser));
    } else {
        loginSection.removeClass('d-none');
    }
});