// script.js - Gestion des tâches CAT ENTREPRISE

// Données initiales des tâches (simulant une base de données)
let tasks = [
    {
        id: 1,
        title: "Préparer la réunion de direction",
        description: "Préparer l'ordre du jour et les documents pour la réunion de direction trimestrielle.",
        dueDate: "2025-04-20",
        priority: "high",
        status: "todo",
        assignee: "user2",
        assigneeName: "Thomas Dupont",
        createdAt: "2025-04-15",
        progress: 0,
        comments: [
            { author: "Sophie Martin", date: "2025-04-15", content: "N'oubliez pas d'inclure les données financières du Q1." }
        ]
    },
    {
        id: 2,
        title: "Finaliser le rapport financier",
        description: "Terminer la rédaction du rapport financier mensuel et l'envoyer à la direction.",
        dueDate: "2025-04-25",
        priority: "medium",
        status: "todo",
        assignee: "user1",
        assigneeName: "Sophie Martin",
        createdAt: "2025-04-16",
        progress: 0,
        comments: []
    },
    {
        id: 3,
        title: "Développer la nouvelle fonctionnalité",
        description: "Implémenter la fonctionnalité de filtrage des tâches dans l'application.",
        dueDate: "2025-04-30",
        priority: "high",
        status: "in-progress",
        assignee: "user4",
        assigneeName: "Nicolas Petit",
        createdAt: "2025-04-10",
        progress: 50,
        comments: [
            { author: "Léa Bernard", date: "2025-04-14", content: "J'ai terminé les maquettes pour cette fonctionnalité." }
        ]
    },
    {
        id: 4,
        title: "Tester l'application mobile",
        description: "Effectuer les tests fonctionnels sur la nouvelle version de l'application mobile.",
        dueDate: "2025-04-22",
        priority: "medium",
        status: "in-progress",
        assignee: "user3",
        assigneeName: "Léa Bernard",
        createdAt: "2025-04-12",
        progress: 75,
        comments: []
    },
    {
        id: 5,
        title: "Mise à jour du site web",
        description: "Mettre à jour le contenu et les images du site web de l'entreprise.",
        dueDate: "2025-04-15",
        priority: "medium",
        status: "completed",
        assignee: "user1",
        assigneeName: "Sophie Martin",
        createdAt: "2025-04-08",
        completedAt: "2025-04-15",
        progress: 100,
        comments: []
    },
    {
        id: 6,
        title: "Formation des nouveaux employés",
        description: "Organiser et conduire la session de formation pour les nouveaux employés du service client.",
        dueDate: "2025-04-12",
        priority: "high",
        status: "completed",
        assignee: "user2",
        assigneeName: "Thomas Dupont",
        createdAt: "2025-04-05",
        completedAt: "2025-04-12",
        progress: 100,
        comments: [
            { author: "Thomas Dupont", date: "2025-04-12", content: "Formation terminée avec succès, 5 participants." }
        ]
    }
];

// Variables globales
let currentFilter = 'all';
let nextTaskId = 7; // Pour générer des IDs uniques pour les nouvelles tâches

// Initialisation de l'application au chargement du DOM
document.addEventListener('DOMContentLoaded', function() {
    // Charger les tâches initiales
    renderTasks();
    
    // Écouteurs d'événements pour les filtres
    document.getElementById('btn-all').addEventListener('click', () => filterTasks('all'));
    document.getElementById('btn-todo').addEventListener('click', () => filterTasks('todo'));
    document.getElementById('btn-in-progress').addEventListener('click', () => filterTasks('in-progress'));
    document.getElementById('btn-completed').addEventListener('click', () => filterTasks('completed'));
    
    // Écouteur pour la recherche
    document.getElementById('searchTasks').addEventListener('input', searchTasks);
    
    // Écouteur pour l'ajout de tâche
    document.getElementById('saveTaskBtn').addEventListener('click', saveTask);
    
    // Écouteurs pour les actions sur les tâches (délégation d'événements)
    document.querySelector('main').addEventListener('click', function(e) {
        // Événement pour ouvrir les détails d'une tâche
        if (e.target.closest('.task-item')) {
            const taskItem = e.target.closest('.task-item');
            const taskId = parseInt(taskItem.dataset.id);
            // Éviter l'ouverture lors du clic sur les actions
            if (!e.target.closest('.task-actions')) {
                showTaskDetails(taskId);
            }
        }
        
        // Événement pour changer le statut d'une tâche
        if (e.target.closest('.change-status')) {
            e.preventDefault();
            const link = e.target.closest('.change-status');
            const taskItem = link.closest('.task-item');
            const taskId = parseInt(taskItem.dataset.id);
            const newStatus = link.dataset.status;
            changeTaskStatus(taskId, newStatus);
        }
    });
    
    // Initialiser les tooltips Bootstrap
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});

// Fonction pour afficher les tâches
function renderTasks() {
    // Réinitialiser les conteneurs
    document.getElementById('todo-tasks').innerHTML = '';
    document.getElementById('in-progress-tasks').innerHTML = '';
    document.getElementById('completed-tasks').innerHTML = '';
    
    // Filtrer les tâches selon le filtre actuel
    const filteredTasks = currentFilter === 'all' 
        ? tasks 
        : tasks.filter(task => task.status === currentFilter);
    
    // Afficher les tâches filtrées
    filteredTasks.forEach(task => {
        const taskItem = createTaskElement(task);
        
        // Ajouter la tâche au conteneur approprié selon son statut
        if (task.status === 'todo') {
            document.getElementById('todo-tasks').appendChild(taskItem);
        } else if (task.status === 'in-progress') {
            document.getElementById('in-progress-tasks').appendChild(taskItem);
        } else if (task.status === 'completed') {
            document.getElementById('completed-tasks').appendChild(taskItem);
        }
    });
    
    // Afficher un message si une colonne est vide
    checkEmptyContainers();
}

// Fonction pour créer l'élément HTML d'une tâche
function createTaskElement(task) {
    const li = document.createElement('li');
    li.className = 'list-group-item task-item';
    li.dataset.id = task.id;
    
    // Déterminer la classe de priorité
    let priorityBadgeClass = '';
    let priorityText = '';
    
    if (task.status === 'completed') {
        priorityBadgeClass = 'bg-success';
        priorityText = 'Complétée';
    } else {
        switch (task.priority) {
            case 'high':
                priorityBadgeClass = 'bg-primary';
                priorityText = 'Priorité: Haute';
                break;
            case 'medium':
                priorityBadgeClass = 'bg-warning text-dark';
                priorityText = 'Priorité: Moyenne';
                break;
            case 'low':
                priorityBadgeClass = 'bg-secondary';
                priorityText = 'Priorité: Basse';
                break;
        }
    }
    
    // Déterminer la classe de la barre de progression
    let progressBarClass = '';
    switch (task.status) {
        case 'todo':
            progressBarClass = 'bg-danger';
            break;
        case 'in-progress':
            progressBarClass = 'bg-warning';
            break;
        case 'completed':
            progressBarClass = 'bg-success';
            break;
    }
    
    // Date à afficher selon le statut
    const dateLabel = task.status === 'completed' ? 'Terminée le' : 'Date limite';
    const dateValue = task.status === 'completed' ? task.completedAt : task.dueDate;
    
    // Créer le contenu HTML
    li.innerHTML = `
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h6 class="mb-1">${task.title}</h6>
                <small class="text-muted">${dateLabel}: ${formatDate(dateValue)}</small>
            </div>
            <div class="task-actions">
                <span class="badge ${priorityBadgeClass} me-1">${priorityText}</span>
                <div class="dropdown d-inline-block">
                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="#" onclick="showTaskDetails(${task.id})"><i class="fas fa-eye me-2"></i> Détails</a></li>
                        <li><a class="dropdown-item" href="#" onclick="editTask(${task.id})"><i class="fas fa-edit me-2"></i> Modifier</a></li>
                        ${getStatusChangeOptions(task.status, task.id)}
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="#" onclick="deleteTask(${task.id})"><i class="fas fa-trash me-2"></i> Supprimer</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="mt-2">
            <div class="progress" style="height: 5px;">
                <div class="progress-bar ${progressBarClass}" role="progressbar" style="width: ${task.progress}%;" aria-valuenow="${task.progress}" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
        </div>
    `;
    
    return li;
}

// Obtenir les options de changement de statut en fonction du statut actuel
function getStatusChangeOptions(currentStatus, taskId) {
    let options = '';
    
    if (currentStatus !== 'todo') {
        options += `<li><a class="dropdown-item change-status" href="#" data-status="todo"><i class="fas fa-arrow-left me-2"></i> Marquer à faire</a></li>`;
    }
    
    if (currentStatus !== 'in-progress') {
        options += `<li><a class="dropdown-item change-status" href="#" data-status="in-progress"><i class="fas fa-spinner me-2"></i> Marquer en cours</a></li>`;
    }
    
    if (currentStatus !== 'completed') {
        options += `<li><a class="dropdown-item change-status" href="#" data-status="completed"><i class="fas fa-check me-2"></i> Marquer terminée</a></li>`;
    }
    
    return options;
}

// Fonction pour filtrer les tâches
function filterTasks(filter) {
    // Mise à jour de l'UI pour les boutons de filtre
    document.querySelectorAll('.btn-outline-primary').forEach(btn => {
        btn.classList.remove('active');
    });
    document.getElementById(`btn-${filter}`).classList.add('active');
    
    // Mise à jour du filtre actuel
    currentFilter = filter;
    
    // Rafraîchir l'affichage
    renderTasks();
}

// Fonction pour rechercher des tâches
function searchTasks() {
    const searchTerm = document.getElementById('searchTasks').value.toLowerCase();
    
    // Si le champ de recherche est vide, afficher toutes les tâches selon le filtre
    if (!searchTerm) {
        renderTasks();
        return;
    }
    
    // Cacher les tâches qui ne correspondent pas à la recherche
    document.querySelectorAll('.task-item').forEach(taskItem => {
        const taskTitle = taskItem.querySelector('h6').textContent.toLowerCase();
        if (taskTitle.includes(searchTerm)) {
            taskItem.style.display = 'block';
        } else {
            taskItem.style.display = 'none';
        }
    });
    
    // Vérifier si des conteneurs sont vides après la recherche
    checkEmptyContainers();
}

// Vérifier si des conteneurs sont vides et afficher un message approprié
function checkEmptyContainers() {
    const containers = [
        { id: 'todo-tasks', message: 'Aucune tâche à faire' },
        { id: 'in-progress-tasks', message: 'Aucune tâche en cours' },
        { id: 'completed-tasks', message: 'Aucune tâche terminée' }
    ];
    
    containers.forEach(container => {
        const el = document.getElementById(container.id);
        if (el.childElementCount === 0) {
            const emptyMessage = document.createElement('div');
            emptyMessage.className = 'empty-tasks';
            emptyMessage.innerHTML = `
                <i class="fas fa-clipboard"></i>
                <p>${container.message}</p>
            `;
            el.appendChild(emptyMessage);
        }
    });
}

// Fonction pour changer le statut d'une tâche
function changeTaskStatus(taskId, newStatus) {
    // Trouver la tâche
    const taskIndex = tasks.findIndex(task => task.id === taskId);
    if (taskIndex === -1) return;
    
    // Mettre à jour le statut
    tasks[taskIndex].status = newStatus;
    
    // Mettre à jour la progression selon le statut
    if (newStatus === 'todo') {
        tasks[taskIndex].progress = 0;
    } else if (newStatus === 'in-progress') {
        tasks[taskIndex].progress = 50;
    } else if (newStatus === 'completed') {
        tasks[taskIndex].progress = 100;
        tasks[taskIndex].completedAt = getCurrentDate();
    }
    
    // Rafraîchir l'affichage
    renderTasks();
    
    // Afficher une notification
    showNotification(`Tâche "${tasks[taskIndex].title}" marquée comme ${getStatusDisplayName(newStatus)}`);
}

// Obtenir le nom d'affichage d'un statut
function getStatusDisplayName(status) {
    switch (status) {
        case 'todo': return 'à faire';
        case 'in-progress': return 'en cours';
        case 'completed': return 'terminée';
        default: return status;
    }
}

// Fonction pour ajouter une nouvelle tâche
function saveTask() {
    // Récupérer les valeurs du formulaire
    const title = document.getElementById('taskTitle').value.trim();
    const description = document.getElementById('taskDescription').value.trim();
    const dueDate = document.getElementById('taskDueDate').value;
    const priority = document.getElementById('taskPriority').value;
    const assignee = document.getElementById('taskAssignee').value;
    const status = document.querySelector('input[name="taskStatus"]:checked').value;
    
    // Validation de base
    if (!title) {
        alert('Veuillez saisir un titre pour la tâche.');
        return;
    }
    
    // Déterminer le nom de l'assigné
    let assigneeName = '';
    if (assignee) {
        const assigneeSelect = document.getElementById('taskAssignee');
        assigneeName = assigneeSelect.options[assigneeSelect.selectedIndex].text;
    }
    
    // Déterminer la progression selon le statut
    let progress = 0;
    if (status === 'in-progress') {
        progress = 50;
    } else if (status === 'completed') {
        progress = 100;
    }
    
    // Créer la nouvelle tâche
    const newTask = {
        id: nextTaskId++,
        title,
        description,
        dueDate,
        priority,
        status,
        assignee,
        assigneeName,
        createdAt: getCurrentDate(),
        progress,
        comments: []
    };
    
    // Si la tâche est terminée, ajouter la date de complétion
    if (status === 'completed') {
        newTask.completedAt = getCurrentDate();
    }
    
    // Ajouter la tâche à la liste
    tasks.push(newTask);
    
    // Fermer le modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('addTaskModal'));
    modal.hide();
    
    // Réinitialiser le formulaire
    document.getElementById('taskForm').reset();
    
    // Rafraîchir l'affichage
    renderTasks();
    
    // Afficher une notification
    showNotification(`Nouvelle tâche "${title}" ajoutée avec succès !`);
}

// Fonction pour afficher les détails d'une tâche
function showTaskDetails(taskId) {
    // Trouver la tâche
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;
    
    // Remplir le modal avec les détails
    const modalContent = document.getElementById('taskDetailsContent');
    
    // Déterminer la classe de priorité
    let priorityBadgeClass = '';
    let priorityText = '';
    
    switch (task.priority) {
        case 'high':
            priorityBadgeClass = 'bg-primary';
            priorityText = 'Haute';
            break;
        case 'medium':
            priorityBadgeClass = 'bg-warning text-dark';
            priorityText = 'Moyenne';
            break;
        case 'low':
            priorityBadgeClass = 'bg-secondary';
            priorityText = 'Basse';
            break;
    }
    
    // Déterminer la classe de statut
    let statusBadgeClass = '';
    let statusText = '';
    
    switch (task.status) {
        case 'todo':
            statusBadgeClass = 'bg-danger';
            statusText = 'À faire';
            break;
        case 'in-progress':
            statusBadgeClass = 'bg-warning text-dark';
            statusText = 'En cours';
            break;
        case 'completed':
            statusBadgeClass = 'bg-success';
            statusText = 'Terminée';
            break;
    }
    
    // Créer le contenu HTML pour les commentaires
    let commentsHtml = '';
    if (task.comments.length > 0) {
        task.comments.forEach(comment => {
            commentsHtml += `
                <div class="comment-item">
                    <div class="d-flex justify-content-between">
                        <span class="comment-author">${comment.author}</span>
                        <span class="comment-date">${comment.date}</span>
                    </div>
                    <p class="mb-0">${comment.content}</p>
                </div>
            `;
        });
    } else {
        commentsHtml = '<p class="text-muted">Aucun commentaire pour cette tâche.</p>';
    }
    
    // Mettre à jour le contenu du modal
    modalContent.innerHTML = `
        <div class="task-details">
            <h4>${task.title}</h4>
            <div class="mb-3">
                <span class="badge ${statusBadgeClass} me-2">${statusText}</span>
                <span class="badge ${priorityBadgeClass}">Priorité: ${priorityText}</span>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <p><strong>Créée le:</strong> ${formatDate(task.createdAt)}</p>
                </div>
                <div class="col-md-6">
                    <p><strong>Date limite:</strong> ${formatDate(task.dueDate)}</p>
                </div>
            </div>
            
            ${task.status === 'completed' ? `<p><strong>Terminée le:</strong> ${formatDate(task.completedAt)}</p>` : ''}
            
            <div class="mb-3">
                <strong>Assignée à:</strong> ${task.assigneeName || 'Non assignée'}
            </div>
            
            <div class="mb-3">
                <strong>Description:</strong>
                <p>${task.description || 'Aucune description fournie.'}</p>
            </div>
            
            <div class="mb-3">
                <strong>Progression:</strong>
                <div class="progress" style="height: 20px;">
                    <div class="progress-bar ${statusBadgeClass}" role="progressbar" style="width: ${task.progress}%;" aria-valuenow="${task.progress}" aria-valuemin="0" aria-valuemax="100">
                        ${task.progress}%
                    </div>
                </div>
            </div>
            
            <div class="comments-section">
                <h5>Commentaires</h5>
                ${commentsHtml}
                
                <div class="mt-3">
                    <textarea class="form-control" id="newComment" placeholder="Ajouter un commentaire..." rows="2"></textarea>
                    <button class="btn btn-sm btn-primary mt-2" onclick="addComment(${task.id})">Ajouter</button>
                </div>
            </div>
        </div>
    `;
    
    // Afficher le modal
    const modal = new bootstrap.Modal(document.getElementById('taskDetailsModal'));
    modal.show();
    
    // Mettre à jour le bouton d'édition
    document.getElementById('editTaskBtn').onclick = function() {
        modal.hide();
        editTask(taskId);
    };
}

// Fonction pour ajouter un commentaire
function addComment(taskId) {
    // Trouver la tâche
    const taskIndex = tasks.findIndex(task => task.id === taskId);
    if (taskIndex === -1) return;
    
    // Récupérer le commentaire
    const commentText = document.getElementById('newComment').value.trim();
    if (!commentText) return;
    
    // Ajouter le commentaire
    tasks[taskIndex].comments.push({
        author: 'Utilisateur actuel', // Normalement, ce serait l'utilisateur connecté
        date: getCurrentDate(),
        content: commentText
    });
    
    // Rafraîchir les détails
    showTaskDetails(taskId);
    
    // Afficher une notification
    showNotification('Commentaire ajouté avec succès !');
}

// Fonction pour modifier une tâche
function editTask(taskId) {
    // Trouver la tâche
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;
    
    // Pré-remplir le formulaire
    document.getElementById('taskTitle').value = task.title;
    document.getElementById('taskDescription').value = task.description || '';
    document.getElementById('taskDueDate').value = task.dueDate;
    document.getElementById('taskPriority').value = task.priority;
    document.getElementById('taskAssignee').value = task.assignee || '';
    
    // Sélectionner le statut
    document.getElementById(`taskStatus${capitalizeFirstLetter(task.status)}`).checked = true;
    
    // Changer le titre du modal
    document.getElementById('addTaskModalLabel').innerHTML = '<i class="fas fa-edit me-2"></i> Modifier la tâche';
    
    // Changer la fonction du bouton de sauvegarde
    document.getElementById('saveTaskBtn').onclick = function() {
        updateTask(taskId);
    };
    
    // Ouvrir le modal
    const modal = new bootstrap.Modal(document.getElementById('addTaskModal'));
    modal.show();
}

// Fonction pour mettre à jour une tâche
function updateTask(taskId) {
    // Trouver la tâche
    const taskIndex = tasks.findIndex(task => task.id === taskId);
    if (taskIndex === -1) return;
    
    // Récupérer les valeurs du formulaire
    const title = document.getElementById('taskTitle').value.trim();
    const description = document.getElementById('taskDescription').value.trim();
    const dueDate = document.getElementById('taskDueDate').value;
    // Continuer la fonction updateTask
    const priority = document.getElementById('taskPriority').value;
    const assignee = document.getElementById('taskAssignee').value;
    const newStatus = document.querySelector('input[name="taskStatus"]:checked').value;
    
    // Validation de base
    if (!title) {
        alert('Veuillez saisir un titre pour la tâche.');
        return;
    }
    
    // Déterminer le nom de l'assigné
    let assigneeName = '';
    if (assignee) {
        const assigneeSelect = document.getElementById('taskAssignee');
        assigneeName = assigneeSelect.options[assigneeSelect.selectedIndex].text;
    }
    
    // Sauvegarder l'ancien statut pour vérifier s'il a changé
    const oldStatus = tasks[taskIndex].status;
    
    // Mettre à jour la tâche
    tasks[taskIndex].title = title;
    tasks[taskIndex].description = description;
    tasks[taskIndex].dueDate = dueDate;
    tasks[taskIndex].priority = priority;
    tasks[taskIndex].assignee = assignee;
    tasks[taskIndex].assigneeName = assigneeName;
    tasks[taskIndex].status = newStatus;
    
    // Mettre à jour la progression selon le statut
    if (newStatus === 'todo') {
        tasks[taskIndex].progress = 0;
    } else if (newStatus === 'in-progress') {
        tasks[taskIndex].progress = 50;
    } else if (newStatus === 'completed') {
        tasks[taskIndex].progress = 100;
        // Ajouter la date de complétion si la tâche est nouvellement terminée
        if (oldStatus !== 'completed') {
            tasks[taskIndex].completedAt = getCurrentDate();
        }
    }
    
    // Fermer le modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('addTaskModal'));
    modal.hide();
    
    // Réinitialiser le formulaire et le bouton
    document.getElementById('taskForm').reset();
    document.getElementById('addTaskModalLabel').innerHTML = '<i class="fas fa-plus-circle me-2"></i> Ajouter une nouvelle tâche';
    document.getElementById('saveTaskBtn').onclick = saveTask;
    
    // Rafraîchir l'affichage
    renderTasks();
    
    // Afficher une notification
    showNotification(`Tâche "${title}" mise à jour avec succès !`);
}

// Fonction pour supprimer une tâche
function deleteTask(taskId) {
    // Demander confirmation
    if (!confirm('Voulez-vous vraiment supprimer cette tâche ?')) {
        return;
    }
    
    // Trouver la tâche
    const taskIndex = tasks.findIndex(task => task.id === taskId);
    if (taskIndex === -1) return;
    
    // Stocker le titre pour la notification
    const taskTitle = tasks[taskIndex].title;
    
    // Supprimer la tâche
    tasks.splice(taskIndex, 1);
    
    // Rafraîchir l'affichage
    renderTasks();
    
    // Afficher une notification
    showNotification(`Tâche "${taskTitle}" supprimée avec succès !`);
}

// Fonction pour afficher une notification
function showNotification(message) {
    // Vérifier si le conteneur de notifications existe, sinon le créer
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container';
        document.body.appendChild(toastContainer);
    }
    
    // Créer la notification
    const toastId = 'toast-' + Date.now();
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    toast.setAttribute('id', toastId);
    
    toast.innerHTML = `
        <div class="toast-header">
            <strong class="me-auto">Notification</strong>
            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body">
            ${message}
        </div>
    `;
    
    // Ajouter la notification au conteneur
    toastContainer.appendChild(toast);
    
    // Afficher la notification
    const toastElement = new bootstrap.Toast(toast, { delay: 3000 });
    toastElement.show();
    
    // Supprimer la notification après qu'elle ait été cachée
    toast.addEventListener('hidden.bs.toast', function() {
        toast.remove();
    });
}

// Fonctions utilitaires

// Formater une date au format français
function formatDate(dateString) {
    if (!dateString) return 'Non définie';
    
    // Conversion de la date au format français
    const date = new Date(dateString);
    return date.toLocaleDateString('fr-FR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    });
}

// Obtenir la date actuelle au format YYYY-MM-DD
function getCurrentDate() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// Mettre en majuscule la première lettre d'une chaîne
function capitalizeFirstLetter(string) {
    if (!string) return '';
    return string.charAt(0).toUpperCase() + string.slice(1);
}

// Fonctions pour l'exportation et l'importation des données
function exportTasks() {
    // Convertir les tâches en chaîne JSON
    const tasksJSON = JSON.stringify(tasks);
    
    // Créer un élément de lien pour télécharger les données
    const a = document.createElement('a');
    const file = new Blob([tasksJSON], { type: 'application/json' });
    a.href = URL.createObjectURL(file);
    a.download = 'cat_tasks_export_' + getCurrentDate() + '.json';
    
    // Déclencher le téléchargement
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    
    // Afficher une notification
    showNotification('Tâches exportées avec succès !');
}

function importTasks() {
    // Créer un élément input pour sélectionner le fichier
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    
    // Écouter l'événement de changement
    input.onchange = e => {
        const file = e.target.files[0];
        
        // Vérifier si un fichier a été sélectionné
        if (!file) return;
        
        // Lire le fichier
        const reader = new FileReader();
        reader.readAsText(file, 'UTF-8');
        
        reader.onload = readerEvent => {
            try {
                // Parser le contenu JSON
                const importedTasks = JSON.parse(readerEvent.target.result);
                
                // Vérifier si c'est un tableau
                if (!Array.isArray(importedTasks)) {
                    throw new Error('Format de données invalide.');
                }
                
                // Demander confirmation
                if (confirm('Voulez-vous remplacer toutes les tâches actuelles par les tâches importées ?')) {
                    // Mettre à jour les tâches
                    tasks = importedTasks;
                    
                    // Mettre à jour l'ID de la prochaine tâche
                    if (tasks.length > 0) {
                        nextTaskId = Math.max(...tasks.map(t => t.id)) + 1;
                    }
                    
                    // Rafraîchir l'affichage
                    renderTasks();
                    
                    // Afficher une notification
                    showNotification('Tâches importées avec succès !');
                }
            } catch (error) {
                // Afficher une erreur
                alert('Erreur lors de l\'importation : ' + error.message);
            }
        };
    };
    
    // Déclencher la fenêtre de sélection de fichier
    input.click();
}

// Fonction pour gérer le mode sombre
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    
    // Enregistrer la préférence dans le stockage local
    const isDarkMode = document.body.classList.contains('dark-mode');
    localStorage.setItem('darkMode', isDarkMode);
    
    // Mettre à jour l'icône du bouton
    const darkModeToggle = document.querySelector('.dark-mode-toggle i');
    if (darkModeToggle) {
        darkModeToggle.className = isDarkMode ? 'fas fa-sun' : 'fas fa-moon';
    }
    
    // Afficher une notification
    showNotification(isDarkMode ? 'Mode sombre activé' : 'Mode clair activé');
}

// Initialiser le mode sombre au chargement
document.addEventListener('DOMContentLoaded', function() {
    // Vérifier la préférence enregistrée
    const isDarkMode = localStorage.getItem('darkMode') === 'true';
    if (isDarkMode) {
        document.body.classList.add('dark-mode');
        
        // Mettre à jour l'icône du bouton
        const darkModeToggle = document.querySelector('.dark-mode-toggle i');
        if (darkModeToggle) {
            darkModeToggle.className = 'fas fa-sun';
        }
    }
    
    // Ajouter un bouton d'exportation et d'importation
    const actionsContainer = document.querySelector('.col-md-6.text-md-end');
    if (actionsContainer) {
        const exportBtn = document.createElement('button');
        exportBtn.className = 'btn btn-outline-secondary ms-2';
        exportBtn.innerHTML = '<i class="fas fa-download me-1"></i> Exporter';
        exportBtn.onclick = exportTasks;
        
        const importBtn = document.createElement('button');
        importBtn.className = 'btn btn-outline-secondary ms-2';
        importBtn.innerHTML = '<i class="fas fa-upload me-1"></i> Importer';
        importBtn.onclick = importTasks;
        
        actionsContainer.appendChild(exportBtn);
        actionsContainer.appendChild(importBtn);
        
        // Ajouter un bouton pour le mode sombre
        const darkModeBtn = document.createElement('button');
        darkModeBtn.className = 'btn btn-outline-secondary ms-2 dark-mode-toggle';
        darkModeBtn.innerHTML = '<i class="fas fa-moon"></i>';
        darkModeBtn.onclick = toggleDarkMode;
        
        actionsContainer.appendChild(darkModeBtn);
    }
});

// Styles CSS pour le mode sombre
function addDarkModeStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .dark-mode {
            background-color: #222;
            color: #f0f0f0;
        }
        
        .dark-mode .card {
            background-color: #333;
            border-color: #444;
        }
        
        .dark-mode .card-header {
            background-color: #444;
            color: #f0f0f0;
        }
        
        .dark-mode .list-group-item {
            background-color: #333;
            border-color: #444;
            color: #f0f0f0;
        }
        
        .dark-mode .navbar {
            background-color: #333 !important;
        }
        
        .dark-mode .navbar-light .navbar-nav .nav-link {
            color: #f0f0f0;
        }
        
        .dark-mode .modal-content {
            background-color: #333;
            color: #f0f0f0;
        }
        
        .dark-mode .modal-header, .dark-mode .modal-footer {
            border-color: #444;
        }
        
        .dark-mode .form-control, .dark-mode .form-select {
            background-color: #444;
            border-color: #555;
            color: #f0f0f0;
        }
        
        .dark-mode .text-muted {
            color: #aaa !important;
        }
        
        .dark-mode .btn-outline-secondary {
            color: #f0f0f0;
            border-color: #666;
        }
        
        .dark-mode .btn-outline-secondary:hover {
            background-color: #444;
        }
        
        .dark-mode .dropdown-menu {
            background-color: #333;
            border-color: #444;
        }
        
        .dark-mode .dropdown-item {
            color: #f0f0f0;
        }
        
        .dark-mode .dropdown-item:hover {
            background-color: #444;
        }
        
        .dark-mode .dropdown-divider {
            border-color: #444;
        }
        
        .dark-mode footer {
            background-color: #222 !important;
        }
    `;
    document.head.appendChild(style);
}

// Ajouter les styles du mode sombre au chargement
document.addEventListener('DOMContentLoaded', addDarkModeStyles);

// Fonctions pour la gestion des équipes
function showTeamsManagement() {
    // Cette fonction pourrait être implémentée dans une version future
    alert('Fonctionnalité de gestion des équipes à venir prochainement !');
}

// Fonction pour afficher les statistiques
function showStatistics() {
    // Calculer les statistiques
    const todoCount = tasks.filter(t => t.status === 'todo').length;
    const inProgressCount = tasks.filter(t => t.status === 'in-progress').length;
    const completedCount = tasks.filter(t => t.status === 'completed').length;
    const totalTasks = tasks.length;
    
    // Calculer les pourcentages
    const todoPercentage = totalTasks > 0 ? (todoCount / totalTasks * 100).toFixed(1) : 0;
    const inProgressPercentage = totalTasks > 0 ? (inProgressCount / totalTasks * 100).toFixed(1) : 0;
    const completedPercentage = totalTasks > 0 ? (completedCount / totalTasks * 100).toFixed(1) : 0;
    
    // Créer le contenu HTML
    const content = `
        <div class="modal-header bg-primary text-white">
            <h5 class="modal-title">Statistiques des Tâches</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div class="row text-center mb-4">
                <div class="col-md-4">
                    <div class="card bg-danger text-white">
                        <div class="card-body">
                            <h1>${todoCount}</h1>
                            <p class="mb-0">À faire</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card bg-warning text-dark">
                        <div class="card-body">
                            <h1>${inProgressCount}</h1>
                            <p class="mb-0">En cours</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card bg-success text-white">
                        <div class="card-body">
                            <h1>${completedCount}</h1>
                            <p class="mb-0">Terminées</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <h5>Répartition des Tâches</h5>
            <div class="progress" style="height: 30px;">
                <div class="progress-bar bg-danger" role="progressbar" style="width: ${todoPercentage}%;" aria-valuenow="${todoPercentage}" aria-valuemin="0" aria-valuemax="100">
                    ${todoPercentage}%
                </div>
                <div class="progress-bar bg-warning" role="progressbar" style="width: ${inProgressPercentage}%;" aria-valuenow="${inProgressPercentage}" aria-valuemin="0" aria-valuemax="100">
                    ${inProgressPercentage}%
                </div>
                <div class="progress-bar bg-success" role="progressbar" style="width: ${completedPercentage}%;" aria-valuenow="${completedPercentage}" aria-valuemin="0" aria-valuemax="100">
                    ${completedPercentage}%
                </div>
            </div>
            
            <div class="mt-4">
                <h5>Tâches par priorité</h5>
                <canvas id="priorityChart" width="400" height="200"></canvas>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
        </div>
    `;
    
    // Créer le modal
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.id = 'statisticsModal';
    modal.setAttribute('tabindex', '-1');
    modal.setAttribute('aria-labelledby', 'statisticsModalLabel');
    modal.setAttribute('aria-hidden', 'true');
    
    modal.innerHTML = `
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                ${content}
            </div>
        </div>
    `;
    
    // Ajouter le modal au document
    document.body.appendChild(modal);
    
    // Afficher le modal
    const modalInstance = new bootstrap.Modal(modal);
    modalInstance.show();
    
    // Nettoyage lors de la fermeture du modal
    modal.addEventListener('hidden.bs.modal', function() {
        modal.remove();
    });
    
    // Créer un graphique des priorités (version simplifiée sans bibliothèque externe)
    setTimeout(() => {
        // Affichage d'un graphique de substitution
        const canvas = document.getElementById('priorityChart');
        const ctx = canvas.getContext('2d');
        
        // Données
        const highPriority = tasks.filter(t => t.priority === 'high').length;
        const mediumPriority = tasks.filter(t => t.priority === 'medium').length;
        const lowPriority = tasks.filter(t => t.priority === 'low').length;
        
        // Dessiner un graphique simple
        const colors = ['#0d6efd', '#ffc107', '#6c757d'];
        const data = [highPriority, mediumPriority, lowPriority];
        const labels = ['Haute', 'Moyenne', 'Basse'];
        
        // Effacer le canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Dessiner les barres
        const barWidth = 50;
        const spacing = 30;
        const startX = 100;
        const maxHeight = 150;
        
        // Trouver la valeur maximale pour l'échelle
        const maxValue = Math.max(...data, 1);
        
        // Dessiner les barres
        for (let i = 0; i < data.length; i++) {
            const x = startX + i * (barWidth + spacing);
            const height = (data[i] / maxValue) * maxHeight;
            const y = canvas.height - 50 - height;
            
            // Dessiner la barre
            ctx.fillStyle = colors[i];
            ctx.fillRect(x, y, barWidth, height);
            
            // Ajouter le label
            ctx.fillStyle = '#000';
            ctx.font = '14px Arial';
            ctx.textAlign = 'center';
            ctx.fillText(labels[i], x + barWidth / 2, canvas.height - 30);
            
            // Ajouter la valeur
            ctx.fillText(data[i], x + barWidth / 2, y - 10);
        }
        
        // Ajouter une légende
        ctx.fillStyle = '#000';
        ctx.font = '16px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('Nombre de tâches par priorité', canvas.width / 2, 20);
    }, 100);
}

// Ajouter les écouteurs d'événements pour les nouvelles fonctionnalités
document.addEventListener('DOMContentLoaded', function() {
    // Ajouter un écouteur pour le lien des statistiques
    const statsLink = document.querySelector('a[href="#"]:has(i.fas.fa-chart-bar)');
    if (statsLink) {
        statsLink.addEventListener('click', function(e) {
            e.preventDefault();
            showStatistics();
        });
    }
});