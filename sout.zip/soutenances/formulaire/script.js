document.addEventListener('DOMContentLoaded', function() {
    // Éléments du DOM
    const form = document.getElementById('immigrationForm');
    const sections = document.querySelectorAll('.form-section');
    const progressBar = document.getElementById('progressBar');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const submitBtn = document.getElementById('submitBtn');
    
    // Variables de contrôle
    let currentSection = 0;
    const totalSections = sections.length;
    
    // Fonction pour mettre à jour l'affichage de la section active
    function showSection(sectionIndex) {
        sections.forEach((section, index) => {
            section.classList.remove('active');
            if (index === sectionIndex) {
                section.classList.add('active');
            }
        });
        
        // Mise à jour des boutons
        prevBtn.disabled = sectionIndex === 0;
        
        if (sectionIndex === totalSections - 1) {
            nextBtn.classList.add('d-none');
            submitBtn.classList.remove('d-none');
        } else {
            nextBtn.classList.remove('d-none');
            submitBtn.classList.add('d-none');
        }
        
        // Mise à jour de la barre de progression
        const progressPercentage = ((sectionIndex + 1) / totalSections) * 100;
        progressBar.style.width = progressPercentage + '%';
        progressBar.setAttribute('aria-valuenow', progressPercentage);
        progressBar.textContent = `Étape ${sectionIndex + 1}/${totalSections}`;
    }
    
    // Validation de la section courante
    function validateCurrentSection() {
        const currentSectionElement = sections[currentSection];
        const requiredInputs = currentSectionElement.querySelectorAll('[required]');
        let isValid = true;
        
        requiredInputs.forEach(input => {
            // Validation des champs obligatoires
            if (input.type === 'radio') {
                // Pour les boutons radio, vérifier si un élément du groupe est sélectionné
                const name = input.name;
                const checkedRadio = currentSectionElement.querySelector(`input[name="${name}"]:checked`);
                if (!checkedRadio) {
                    isValid = false;
                    // Mettre en évidence le groupe de boutons radio
                    const radioGroup = currentSectionElement.querySelector(`input[name="${name}"]`).closest('.mb-3');
                    radioGroup.classList.add('was-validated');
                }
            } else if (input.type === 'checkbox') {
                if (!input.checked) {
                    isValid = false;
                    input.classList.add('is-invalid');
                } else {
                    input.classList.remove('is-invalid');
                }
            } else {
                if (!input.value.trim()) {
                    isValid = false;
                    input.classList.add('is-invalid');
                } else {
                    input.classList.remove('is-invalid');
                }
            }
        });
        
        return isValid;
    }
    
    // Événement: bouton suivant
    nextBtn.addEventListener('click', function() {
        if (validateCurrentSection()) {
            currentSection++;
            if (currentSection < totalSections) {
                showSection(currentSection);
                window.scrollTo(0, 0);
            }
        } else {
            // Afficher un message d'erreur
            alert('Veuillez remplir tous les champs obligatoires marqués d\'un astérisque (*).');
        }
    });
    
    // Événement: bouton précédent
    prevBtn.addEventListener('click', function() {
        currentSection--;
        if (currentSection >= 0) {
            showSection(currentSection);
            window.scrollTo(0, 0);
        }
    });
    
    // Événement: soumission du formulaire
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (validateCurrentSection()) {
            // Simulation de l'envoi des données
            const formData = new FormData(form);
            
            // Afficher le spinner pendant la "soumission"
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Traitement en cours...';
            submitBtn.disabled = true;
            
            // Simuler un délai de traitement (à remplacer par un vrai appel API)
            setTimeout(function() {
                // Réinitialiser le bouton
                submitBtn.innerHTML = 'Soumettre';
                submitBtn.disabled = false;
                
                // Afficher le modal de confirmation
                const confirmationModal = new bootstrap.Modal(document.getElementById('confirmationModal'));
                confirmationModal.show();
                
                // Réinitialiser le formulaire (optionnel)
                // form.reset();
                // currentSection = 0;
                // showSection(currentSection);
            }, 2000);
        } else {
            // Afficher un message d'erreur
            alert('Veuillez remplir tous les champs obligatoires marqués d\'un astérisque (*).');
        }
    });
    
    // Validation en temps réel des champs
    const allInputs = form.querySelectorAll('input, select, textarea');
    allInputs.forEach(input => {
        input.addEventListener('input', function() {
            if (this.hasAttribute('required')) {
                if (this.value.trim()) {
                    this.classList.remove('is-invalid');
                    this.classList.add('is-valid');
                } else {
                    this.classList.remove('is-valid');
                    this.classList.add('is-invalid');
                }
            }
        });
    });
    
    // Validation des boutons radio
    const radioGroups = form.querySelectorAll('input[type="radio"]');
    radioGroups.forEach(radio => {
        radio.addEventListener('change', function() {
            if (this.hasAttribute('required')) {
                const name = this.name;
                const radioGroup = form.querySelector(`input[name="${name}"]`).closest('.mb-3');
                radioGroup.classList.add('was-validated');
            }
        });
    });
    
    // Initialisation: afficher la première section
    showSection(currentSection);
});
