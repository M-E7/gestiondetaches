// Donnés de démonstration (simulées)
let tasks = [
    {
        id: 1,
        title: "Préparer le rapport mensuel",
        description: "Rassembler les chiffres de vente du mois et préparer le rapport pour la direction.",
        dueDate: "2025-04-25",
        creationDate: "2025-04-10",
        priority: "high",
        status: "in-progress",
        requiresDocument: true,
        document: null
    },
    {
        id: 2,
        title: "Mettre à jour le site web",
        description: "Ajouter les nouvelles promotions sur la page d'accueil et corriger les bugs signalés par les utilisateurs.",
        dueDate: "2025-04-20",
        creationDate: "2025-04-12",
        priority: "medium",
        status: "pending",
        requiresDocument: true,
        document: null
    },
    {
        id: 3,
        title: "Répondre aux emails clients",
        description: "Traiter les demandes d'information et les réclamations des clients dans la boîte mail support@catentreprise.com",
        dueDate: "2025-04-19",
        creationDate: "2025-04-18",
        priority: "high",
        status: "pending",
        requiresDocument: false,
        document: null
    },
    {
        id: 4,
        title: "Planifier la réunion d'équipe",
        description: "Organiser la réunion mensuelle d'équipe, préparer l'ordre du jour et réserver la salle de conférence.",
        dueDate: "2025-04-22",
        creationDate: "2025-04-15",
        priority: "low",
        status: "completed",
        requiresDocument: false,
        document: null
    },
    {
        id: 5,
        title: "Soumettre les notes de frais",
        description: "Compiler et soumettre les notes de frais du mois de mars pour remboursement.",
        dueDate: "2025-04-30",
        creationDate: "2025-04-14",
        priority: "medium",
        status: "validation",
        requiresDocument: true,
        document: {
            name: "frais-mars-2025.pdf",
            date: "2025-04-17"
        }
    }
];

// Variables pour suivre les filtres actuels
let currentStatusFilter = 'all';
let currentPriorityFilter = 'all';
let currentValidationFilter = 'all';
let currentSortOption = 'due-date';
let currentTaskId = null;

// Initialisation de l'application
document.addEventListener('DOMContentLoaded', function() {
    // Charger les tâches initiales
    renderTasks();
    
    // Configurer les écouteurs d'événements
    setupEventListeners();
});

// Configuration des écouteurs d'événements
function setupEventListeners() {
    // Filtres
    document.getElementById('statusFilter').addEventListener('change', handleFiltersChange);
    document.getElementById('priorityFilter').addEventListener('change', handleFiltersChange);
    document.getElementById('validationFilter').addEventListener('change', handleFiltersChange);
    document.getElementById('sortOption').addEventListener('change', handleFiltersChange);
    
    // Ajout de tâche
    document.getElementById('saveTaskBtn').addEventListener('click', saveNewTask);
    
    // Upload de document
    document.getElementById('submitDocumentBtn').addEventListener('click', submitDocument);
}

// Gestion des changements de filtres
function handleFiltersChange() {
    currentStatusFilter = document.getElementById('statusFilter').value;
    currentPriorityFilter = document.getElementById('priorityFilter').value;
    currentValidationFilter = document.getElementById('validationFilter').value;
    currentSortOption = document.getElementById('sortOption').value;
    
    renderTasks();
}

// Filtre les tâches selon les critères sélectionnés
function filterTasks() {
    return tasks.filter(task => {
        // Filtre de statut
        if (currentStatusFilter !== 'all' && task.status !== currentStatusFilter) {
            return false;
        }
        
        // Filtre de priorité
        if (currentPriorityFilter !== 'all' && task.priority !== currentPriorityFilter) {
            return false;
        }
        
        // Filtre de validation documentaire
        if (currentValidationFilter === 'with-document' && !task.requiresDocument) {
            return false;
        } else if (currentValidationFilter === 'without-document' && task.requiresDocument) {
            return false;
        }
        
        return true;
    });
}

// Trie les tâches selon l'option sélectionnée
function sortTasks(filteredTasks) {
    return filteredTasks.sort((a, b) => {
        switch (currentSortOption) {
            case 'due-date':
                return new Date(a.dueDate) - new Date(b.dueDate);
            case 'priority':
                const priorityOrder = { 'high': 0, 'medium': 1, 'low': 2 };
                return priorityOrder[a.priority] - priorityOrder[b.priority];
            case 'creation-date':
                return new Date(a.creationDate) - new Date(b.creationDate);
            case 'title':
                return a.title.localeCompare(b.title);
            default:
                return 0;
        }
    });
}

// Rendu de la liste des tâches
function renderTasks() {
    const taskList = document.getElementById('taskList');
    const filteredTasks = filterTasks();
    const sortedTasks = sortTasks(filteredTasks);
    
    taskList.innerHTML = '';
    
    if (sortedTasks.length === 0) {
        taskList.innerHTML = `
            <div class="alert alert-info text-center">
                Aucune tâche ne correspond aux critères sélectionnés.
            </div>
        `;
        return;
    }
    
    sortedTasks.forEach(task => {
        const taskCard = document.createElement('div');
        taskCard.className = `card task-card ${task.priority}-priority ${task.status}`;
        taskCard.dataset.taskId = task.id;
        
        // Vérifier si la date d'échéance est dépassée
        const isOverdue = new Date(task.dueDate) < new Date() && task.status !== 'completed';
        
        taskCard.innerHTML = `
            <div class="card-body">
                <div class="row">
                    <div class="col-md-8">
                        <h5 class="task-title" data-bs-toggle="modal" data-bs-target="#taskDetailModal" data-task-id="${task.id}">
                            ${task.title}
                            ${task.requiresDocument ? '<i class="fas fa-file-alt document-indicator" title="Nécessite un document"></i>' : ''}
                        </h5>
                        <p class="task-description">${task.description}</p>
                        <p class="mb-2">
                            <span class="priority-indicator priority-${task.priority}" title="Priorité ${task.priority === 'high' ? 'haute' : task.priority === 'medium' ? 'moyenne' : 'basse'}"></span>
                            <span class="status-badge status-${task.status}">
                                ${getStatusLabel(task.status)}
                            </span>
                            <span class="ms-2 due-date ${isOverdue ? 'overdue' : ''}">
                                <i class="far fa-calendar-alt me-1"></i>${formatDate(task.dueDate)}
                                ${isOverdue ? '<span class="ms-1">(En retard)</span>' : ''}
                            </span>
                        </p>
                    </div>
                    <div class="col-md-4">
                        <div class="task-actions d-flex justify-content-end">
                            ${renderTaskActions(task)}
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        taskList.appendChild(taskCard);
    });
    
    // Ajouter les écouteurs pour les boutons d'action
    setupTaskActionListeners();
    
    // Ajouter des écouteurs pour les détails des tâches
    document.querySelectorAll('.task-title').forEach(title => {
        title.addEventListener('click', function() {
            const taskId = parseInt(this.dataset.taskId);
            openTaskDetails(taskId);
        });
    });
}

// Génère les boutons d'action appropriés selon l'état de la tâche
function renderTaskActions(task) {
    let actions = '';
    
    switch (task.status) {
        case 'pending':
            actions += `<button class="btn btn-sm btn-outline-primary start-task-btn" data-task-id="${task.id}">
                <i class="fas fa-play me-1"></i>Commencer
            </button>`;
            break;
        case 'in-progress':
            if (task.requiresDocument) {
                actions += `<button class="btn btn-sm btn-outline-purple submit-doc-btn" data-task-id="${task.id}" data-bs-toggle="modal" data-bs-target="#uploadDocumentModal">
                    <i class="fas fa-file-upload me-1"></i>Soumettre
                </button>`;
            } else {
                actions += `<button class="btn btn-sm btn-outline-success complete-task-btn" data-task-id="${task.id}">
                    <i class="fas fa-check me-1"></i>Terminer
                </button>`;
            }
            actions += `<button class="btn btn-sm btn-outline-secondary pause-task-btn" data-task-id="${task.id}">
                <i class="fas fa-pause me-1"></i>Mettre en attente
            </button>`;
            break;
        case 'validation':
            actions += `<span class="text-purple">
                <i class="fas fa-hourglass-half me-1"></i>En attente de validation
            </span>`;
            break;
        case 'completed':
            actions += `<span class="text-success">
                <i class="fas fa-check-circle me-1"></i>Tâche terminée
            </span>`;
            break;
    }
    
    return actions;
}

// Configure les écouteurs d'événements pour les boutons d'action des tâches
function setupTaskActionListeners() {
    // Bouton "Commencer"
    document.querySelectorAll('.start-task-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const taskId = parseInt(this.dataset.taskId);
            changeTaskStatus(taskId, 'in-progress');
        });
    });
    
    // Bouton "Terminer"
    document.querySelectorAll('.complete-task-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const taskId = parseInt(this.dataset.taskId);
            changeTaskStatus(taskId, 'completed');
        });
    });
    
    // Bouton "Mettre en attente"
    document.querySelectorAll('.pause-task-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const taskId = parseInt(this.dataset.taskId);
            changeTaskStatus(taskId, 'pending');
        });
    });
    
    // Bouton "Soumettre document"
    document.querySelectorAll('.submit-doc-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            currentTaskId = parseInt(this.dataset.taskId);
        });
    });
}

// Change le statut d'une tâche
function changeTaskStatus(taskId, newStatus) {
    const taskIndex = tasks.findIndex(task => task.id === taskId);
    if (taskIndex !== -1) {
        tasks[taskIndex].status = newStatus;
        renderTasks();
        
        // Notification de changement de statut
        showToast(`Statut de la tâche modifié: ${getStatusLabel(newStatus)}`);
    }
}

// Ouvre les détails d'une tâche dans une modal
function openTaskDetails(taskId) {
    currentTaskId = taskId;
    const task = tasks.find(t => t.id === taskId);
    
    if (!task) return;
    
    const modalTitle = document.getElementById('taskDetailTitle');
    const modalBody = document.getElementById('taskDetailBody');
    const modalFooter = document.getElementById('taskDetailFooter');
    
    modalTitle.textContent = task.title;
    
    modalBody.innerHTML = `
        <div class="row mb-3">
            <div class="col-md-12">
                <h6 class="fw-bold">Description:</h6>
                <p>${task.description}</p>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-md-4">
                <h6 class="fw-bold">Priorité:</h6>
                <p>
                    <span class="priority-indicator priority-${task.priority}"></span>
                    ${task.priority === 'high' ? 'Haute' : task.priority === 'medium' ? 'Moyenne' : 'Basse'}
                </p>
            </div>
            <div class="col-md-4">
                <h6 class="fw-bold">Statut:</h6>
                <p><span class="status-badge status-${task.status}">${getStatusLabel(task.status)}</span></p>
            </div>
            <div class="col-md-4">
                <h6 class="fw-bold">Échéance:</h6>
                <p>${formatDate(task.dueDate)}</p>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-md-6">
                <h6 class="fw-bold">Date de création:</h6>
                <p>${formatDate(task.creationDate)}</p>
            </div>
            <div class="col-md-6">
                <h6 class="fw-bold">Validation documentaire:</h6>
                <p>${task.requiresDocument ? 'Requise' : 'Non requise'}</p>
            </div>
        </div>
        ${task.document ? `
        <div class="row mb-3">
            <div class="col-md-12">
                <h6 class="fw-bold">Document soumis:</h6>
                <div class="d-flex align-items-center">
                    <i class="fas fa-file-pdf text-danger fs-4 me-2"></i>
                    <div>
                        <p class="mb-0">${task.document.name}</p>
                        <small class="text-muted">Soumis le ${formatDate(task.document.date)}</small>
                    </div>
                </div>
            </div>
        </div>` : ''}
    `;
    
    // Générer les boutons d'action pour le pied de modal
    modalFooter.innerHTML = '';
    
    // Bouton "Fermer" (toujours présent)
    const closeButton = document.createElement('button');
    closeButton.type = 'button';
    closeButton.className = 'btn btn-secondary';
    closeButton.setAttribute('data-bs-dismiss', 'modal');
    closeButton.textContent = 'Fermer';
    modalFooter.appendChild(closeButton);
    
    // Ajouter des boutons d'action selon le statut
    if (task.status === 'pending') {
        const startButton = document.createElement('button');
        startButton.type = 'button';
        startButton.className = 'btn btn-primary';
        startButton.innerHTML = '<i class="fas fa-play me-1"></i>Commencer';
        startButton.addEventListener('click', function() {
            changeTaskStatus(taskId, 'in-progress');
            
            // Fermer la modal après l'action
            const modal = bootstrap.Modal.getInstance(document.getElementById('taskDetailModal'));
            modal.hide();
        });
        modalFooter.appendChild(startButton);
    } else if (task.status === 'in-progress') {
        if (task.requiresDocument) {
            const submitButton = document.createElement('button');
            submitButton.type = 'button';
            submitButton.className = 'btn btn-primary';
            submitButton.innerHTML = '<i class="fas fa-file-upload me-1"></i>Soumettre Document';
            submitButton.addEventListener('click', function() {
                // Fermer la modal de détails
                const detailModal = bootstrap.Modal.getInstance(document.getElementById('taskDetailModal'));
                detailModal.hide();
                
                // Ouvrir la modal d'upload
                currentTaskId = taskId;
                setTimeout(() => {
                    const uploadModal = new bootstrap.Modal(document.getElementById('uploadDocumentModal'));
                    uploadModal.show();
                }, 500);
            });
            modalFooter.appendChild(submitButton);
        } else {
            const completeButton = document.createElement('button');
            completeButton.type = 'button';
            completeButton.className = 'btn btn-success';
            completeButton.innerHTML = '<i class="fas fa-check me-1"></i>Terminer';
            completeButton.addEventListener('click', function() {
                changeTaskStatus(taskId, 'completed');
                
                // Fermer la modal après l'action
                const modal = bootstrap.Modal.getInstance(document.getElementById('taskDetailModal'));
                modal.hide();
            });
            modalFooter.appendChild(completeButton);
        }
        
        const pauseButton = document.createElement('button');
        pauseButton.type = 'button';
        pauseButton.className = 'btn btn-outline-secondary';
        pauseButton.innerHTML = '<i class="fas fa-pause me-1"></i>Mettre en Attente';
        pauseButton.addEventListener('click', function() {
            changeTaskStatus(taskId, 'pending');
            
            // Fermer la modal après l'action
            const modal = bootstrap.Modal.getInstance(document.getElementById('taskDetailModal'));
            modal.hide();
        });
        modalFooter.appendChild(pauseButton);
    }
}

// Enregistre une nouvelle tâche
function saveNewTask() {
    const title = document.getElementById('taskTitle').value.trim();
    const description = document.getElementById('taskDescription').value.trim();
    const dueDate = document.getElementById('taskDueDate').value;
    const priority = document.getElementById('taskPriority').value;
    const requiresDocument = document.getElementById('requiresDocument').checked;
    
    // Validation de base
    if (!title) {
        alert('Le titre de la tâche est obligatoire.');
        return;
    }
    
    // Générer un nouvel ID unique
    const newId = tasks.length > 0 ? Math.max(...tasks.map(task => task.id)) + 1 : 1;
    
    // Créer la nouvelle tâche
    const newTask = {
        id: newId,
        title: title,
        description: description,
        dueDate: dueDate || formatDateForInput(new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)), // Par défaut: aujourd'hui + 7 jours
        creationDate: formatDateForInput(new Date()),
        priority: priority,
        status: 'pending',
        requiresDocument: requiresDocument,
        document: null
    };
    
    // Ajouter la tâche à la liste
    tasks.push(newTask);
    
    // Réinitialiser le formulaire
    document.getElementById('addTaskForm').reset();
    
    // Fermer la modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('addTaskModal'));
    modal.hide();
    
    // Rafraîchir l'affichage
    renderTasks();
    
    // Notification
    showToast('Nouvelle tâche créée avec succès !');
}

// Soumission d'un document pour une tâche
function submitDocument() {
    if (!currentTaskId) return;
    
    const fileInput = document.getElementById('taskDocument');
    
    // Validation de base
    if (!fileInput.files || fileInput.files.length === 0) {
        alert('Veuillez sélectionner un fichier.');
        return;
    }
    
    const fileName = fileInput.files[0].name;
    
    // Mettre à jour la tâche
    const taskIndex = tasks.findIndex(task => task.id === currentTaskId);
    if (taskIndex !== -1) {
        tasks[taskIndex].status = 'validation';
        tasks[taskIndex].document = {
            name: fileName,
            date: formatDateForInput(new Date())
        };
        
        // Réinitialiser le formulaire
        document.getElementById('uploadDocumentForm').reset();
        
        // Fermer la modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('uploadDocumentModal'));
        modal.hide();
        
        // Rafraîchir l'affichage
        renderTasks();
        
        // Notification
        showToast('Document soumis avec succès !');
    }
}

// Formater une date pour affichage
function formatDate(dateString) {
    if (!dateString) return 'Non définie';
    
    const options = { day: '2-digit', month: '2-digit', year: 'numeric' };
    return new Date(dateString).toLocaleDateString('fr-FR', options);
}

// Formater une date pour les champs input de type date
function formatDateForInput(date) {
    return date.toISOString().split('T')[0];
}

// Obtenir le libellé d'un statut
function getStatusLabel(status) {
    switch (status) {
        case 'pending': return 'En attente';
        case 'in-progress': return 'En cours';
        case 'completed': return 'Terminée';
        case 'validation': return 'En validation';
        default: return status;
    }
}

// Afficher une notification toast
function showToast(message) {
    // Créer un élément toast s'il n'existe pas déjà
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(toastContainer);
    }
    
    // Créer le toast
    const toastId = `toast-${Date.now()}`;
    const toastElement = document.createElement('div');
    toastElement.id = toastId;
    toastElement.className = 'toast';
    toastElement.setAttribute('role', 'alert');
    toastElement.setAttribute('aria-live', 'assertive');
    toastElement.setAttribute('aria-atomic', 'true');
    
    toastElement.innerHTML = `
        <div class="toast-header">
            <i class="fas fa-cat me-2 text-primary"></i>
            <strong class="me-auto">CAT ENTREPRISE</strong>
            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body">
            ${message}
        </div>
    `;
    
    toastContainer.appendChild(toastElement);
    
    // Afficher le toast
    const toast = new bootstrap.Toast(toastElement, { autohide: true, delay: 3000 });
    toast.show();
    
    // Supprimer le toast après disparition
    toastElement.addEventListener('hidden.bs.toast', function() {
        this.remove();
    });
}
// Fonction de recherche de tâches
function searchTasks(searchTerm) {
    if (!searchTerm) {
        renderTasks(); // Réinitialiser à toutes les tâches si la recherche est vide
        return;
    }
    
    searchTerm = searchTerm.toLowerCase();
    const taskList = document.getElementById('taskList');
    
    // Filtrer les tâches selon le terme recherché
    const searchResults = tasks.filter(task => 
        task.title.toLowerCase().includes(searchTerm) || 
        task.description.toLowerCase().includes(searchTerm)
    );
    
    // Afficher les résultats
    taskList.innerHTML = '';
    
    if (searchResults.length === 0) {
        taskList.innerHTML = `
            <div class="alert alert-info text-center">
                Aucune tâche ne correspond à votre recherche "${searchTerm}".
            </div>
        `;
        return;
    }
    
    // Afficher les résultats de recherche
    searchResults.forEach(task => {
        const taskCard = document.createElement('div');
        taskCard.className = `card task-card ${task.priority}-priority ${task.status}`;
        taskCard.dataset.taskId = task.id;
        
        // Vérifier si la date d'échéance est dépassée
        const isOverdue = new Date(task.dueDate) < new Date() && task.status !== 'completed';
        
        taskCard.innerHTML = `
            <div class="card-body">
                <div class="row">
                    <div class="col-md-8">
                        <h5 class="task-title" data-bs-toggle="modal" data-bs-target="#taskDetailModal" data-task-id="${task.id}">
                            ${task.title}
                            ${task.requiresDocument ? '<i class="fas fa-file-alt document-indicator" title="Nécessite un document"></i>' : ''}
                        </h5>
                        <p class="task-description">${task.description}</p>
                        <p class="mb-2">
                            <span class="priority-indicator priority-${task.priority}" title="Priorité ${task.priority === 'high' ? 'haute' : task.priority === 'medium' ? 'moyenne' : 'basse'}"></span>
                            <span class="status-badge status-${task.status}">
                                ${getStatusLabel(task.status)}
                            </span>
                            <span class="ms-2 due-date ${isOverdue ? 'overdue' : ''}">
                                <i class="far fa-calendar-alt me-1"></i>${formatDate(task.dueDate)}
                                ${isOverdue ? '<span class="ms-1">(En retard)</span>' : ''}
                            </span>
                        </p>
                    </div>
                    <div class="col-md-4">
                        <div class="task-actions d-flex justify-content-end">
                            ${renderTaskActions(task)}
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        taskList.appendChild(taskCard);
    });
    
    // Réattacher les écouteurs d'événements
    setupTaskActionListeners();
    
    // Écouteurs pour les détails des tâches
    document.querySelectorAll('.task-title').forEach(title => {
        title.addEventListener('click', function() {
            const taskId = parseInt(this.dataset.taskId);
            openTaskDetails(taskId);
        });
    });
}

// Ajout des fonctions pour le dashboard
function generateDashboardData() {
    // Calcul des statistiques pour le dashboard
    const stats = {
        total: tasks.length,
        byStatus: {
            pending: tasks.filter(t => t.status === 'pending').length,
            inProgress: tasks.filter(t => t.status === 'in-progress').length,
            validation: tasks.filter(t => t.status === 'validation').length,
            completed: tasks.filter(t => t.status === 'completed').length
        },
        byPriority: {
            high: tasks.filter(t => t.priority === 'high').length,
            medium: tasks.filter(t => t.priority === 'medium').length,
            low: tasks.filter(t => t.priority === 'low').length
        },
        overdue: tasks.filter(t => new Date(t.dueDate) < new Date() && t.status !== 'completed').length,
        requiresDocument: tasks.filter(t => t.requiresDocument).length,
        completionRate: tasks.length > 0 ? Math.round((tasks.filter(t => t.status === 'completed').length / tasks.length) * 100) : 0
    };
    
    return stats;
}

function renderDashboard() {
    const stats = generateDashboardData();
    const dashboardContent = document.getElementById('dashboardContent');
    
    if (!dashboardContent) return;
    
    dashboardContent.innerHTML = `
        <div class="row g-4">
            <!-- Sommaire -->
            <div class="col-md-4">
                <div class="card h-100 shadow-sm">
                    <div class="card-body text-center">
                        <h3 class="card-title">${stats.total}</h3>
                        <p class="card-text text-muted">Tâches au total</p>
                        <div class="progress mt-3">
                            <div class="progress-bar bg-success" role="progressbar" style="width: ${stats.completionRate}%" 
                                aria-valuenow="${stats.completionRate}" aria-valuemin="0" aria-valuemax="100">
                                ${stats.completionRate}% Terminées
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Répartition par statut -->
            <div class="col-md-4">
                <div class="card h-100 shadow-sm">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Statuts</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="statusChart" height="200"></canvas>
                    </div>
                </div>
            </div>
            
            <!-- Répartition par priorité -->
            <div class="col-md-4">
                <div class="card h-100 shadow-sm">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Priorités</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="priorityChart" height="200"></canvas>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row g-4 mt-4">
            <!-- Tasks Overview -->
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">Aperçu des Tâches</h5>
                        <button class="btn btn-sm btn-outline-primary" id="refreshDashboardBtn">
                            <i class="fas fa-sync-alt"></i>
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="row text-center g-3">
                            <div class="col-md-3 col-6">
                                <div class="p-3 rounded bg-light">
                                    <h3>${stats.byStatus.pending}</h3>
                                    <p class="text-muted mb-0">En attente</p>
                                </div>
                            </div>
                            <div class="col-md-3 col-6">
                                <div class="p-3 rounded bg-light">
                                    <h3>${stats.byStatus.inProgress}</h3>
                                    <p class="text-muted mb-0">En cours</p>
                                </div>
                            </div>
                            <div class="col-md-3 col-6">
                                <div class="p-3 rounded bg-light">
                                    <h3>${stats.byStatus.validation}</h3>
                                    <p class="text-muted mb-0">En validation</p>
                                </div>
                            </div>
                            <div class="col-md-3 col-6">
                                <div class="p-3 rounded bg-light">
                                    <h3>${stats.byStatus.completed}</h3>
                                    <p class="text-muted mb-0">Terminées</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Alerts -->
            <div class="col-md-4">
                <div class="card shadow-sm">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Alertes</h5>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-${stats.overdue > 0 ? 'danger' : 'success'} d-flex align-items-center" role="alert">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <div>
                                ${stats.overdue} tâche${stats.overdue !== 1 ? 's' : ''} en retard
                            </div>
                        </div>
                        <div class="alert alert-info d-flex align-items-center" role="alert">
                            <i class="fas fa-file-alt me-2"></i>
                            <div>
                                ${stats.requiresDocument} tâche${stats.requiresDocument !== 1 ? 's' : ''} nécessite${stats.requiresDocument !== 1 ? 'nt' : ''} un document
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Création des graphiques
    createStatusChart(stats);
    createPriorityChart(stats);
    
    // Écouteur pour le bouton de rafraîchissement
    document.getElementById('refreshDashboardBtn')?.addEventListener('click', renderDashboard);
}

function createStatusChart(stats) {
    const ctx = document.getElementById('statusChart');
    
    if (!ctx) return;
    
    // Détruire le chart existant s'il y en a un
    if (window.statusChart) {
        window.statusChart.destroy();
    }
    
    window.statusChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['En attente', 'En cours', 'En validation', 'Terminées'],
            datasets: [{
                data: [stats.byStatus.pending, stats.byStatus.inProgress, stats.byStatus.validation, stats.byStatus.completed],
                backgroundColor: ['#9e9e9e', '#2196f3', '#9c27b0', '#8bc34a'],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

function createPriorityChart(stats) {
    const ctx = document.getElementById('priorityChart');
    
    if (!ctx) return;
    
    // Détruire le chart existant s'il y en a un
    if (window.priorityChart) {
        window.priorityChart.destroy();
    }
    
    window.priorityChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Haute', 'Moyenne', 'Basse'],
            datasets: [{
                data: [stats.byPriority.high, stats.byPriority.medium, stats.byPriority.low],
                backgroundColor: ['#f44336', '#ff9800', '#4caf50'],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

// Mise à jour des écouteurs d'événements dans la fonction setupEventListeners
function setupEventListeners() {
    // Filtres existants
    document.getElementById('statusFilter').addEventListener('change', handleFiltersChange);
    document.getElementById('priorityFilter').addEventListener('change', handleFiltersChange);
    document.getElementById('validationFilter').addEventListener('change', handleFiltersChange);
    document.getElementById('sortOption').addEventListener('change', handleFiltersChange);
    
    // Ajout des écouteurs pour la recherche
    document.getElementById('searchButton')?.addEventListener('click', function() {
        const searchTerm = document.getElementById('searchInput').value.trim();
        searchTasks(searchTerm);
    });
    
    document.getElementById('searchInput')?.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            const searchTerm = this.value.trim();
            searchTasks(searchTerm);
        }
    });
    
    // Écouteurs pour le dashboard dans la navigation
    document.querySelectorAll('.nav-link').forEach(navLink => {
        navLink.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Retirer la classe active de tous les liens
            document.querySelectorAll('.nav-link').forEach(link => {
                link.classList.remove('active');
            });
            
            // Ajouter la classe active au lien cliqué
            this.classList.add('active');
            
            // Afficher la vue correspondante
            if (this.textContent.includes('Tableau de Bord')) {
                document.getElementById('tasksView').classList.add('d-none');
                document.getElementById('dashboardView').classList.remove('d-none');
                renderDashboard();
            } else if (this.textContent.includes('Mes Tâches')) {
                document.getElementById('dashboardView').classList.add('d-none');
                document.getElementById('tasksView').classList.remove('d-none');
            }
        });
    });
    
    // Écouteurs pour l'ajout de tâches et l'upload de document
    document.getElementById('saveTaskBtn').addEventListener('click', saveNewTask);
    document.getElementById('submitDocumentBtn').addEventListener('click', submitDocument);
}