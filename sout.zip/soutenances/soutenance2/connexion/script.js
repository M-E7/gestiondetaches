// Fonction pour basculer la visibilité du mot de passe
function togglePasswordVisibility() {
    const passwordInput = document.getElementById('password');
    const toggleIcon = document.getElementById('toggleIcon');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleIcon.classList.remove('fa-eye');
        toggleIcon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        toggleIcon.classList.remove('fa-eye-slash');
        toggleIcon.classList.add('fa-eye');
    }
}

// Gérer la soumission du formulaire
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const rememberMe = document.getElementById('rememberMe').checked;
        
        // Validation simple côté client
        if (!email || !password) {
            showAlert('Veuillez remplir tous les champs', 'danger');
            return;
        }
        
        // Simulation de connexion (à remplacer par une vraie authentification)
        simulateLogin(email, password, rememberMe);
    });
    
    // Vérifier si le mode sombre est activé
    checkDarkMode();
    
    // Ajouter un bouton pour le mode sombre
    addDarkModeToggle();
    
    // Animer l'apparition des éléments
    animateElements();
});

// Simuler une connexion (pour démonstration)
function simulateLogin(email, password, rememberMe) {
    // Afficher un chargement pendant la "connexion"
    showLoading();
    
    // Simule une requête d'API
    setTimeout(() => {
        // Démonstration avec des identifiants prédéfinis
        if (email === 'demo@catentreprise.com' && password === 'demo123') {
            if (rememberMe) {
                localStorage.setItem('rememberedUser', email);
            } else {
                localStorage.removeItem('rememberedUser');
            }
            
            showAlert('Connexion réussie! Redirection en cours...', 'success');
            
            // Rediriger vers la page principale après 1.5 secondes
            setTimeout(() => {
                window.location.href = 'index.html';
            }, 1500);
        } else {
            hideLoading();
            showAlert('Identifiants incorrects. Veuillez réessayer.', 'danger');
        }
    }, 1500);
}

// Afficher une alerte
function showAlert(message, type) {
    // Supprimer toute alerte existante
    const existingAlert = document.querySelector('.login-alert');
    if (existingAlert) {
        existingAlert.remove();
    }
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} login-alert`;
    alertDiv.role = 'alert';
    alertDiv.innerHTML = message;
    
    // Insérer l'alerte avant le formulaire
    const form = document.getElementById('loginForm');
    form.parentNode.insertBefore(alertDiv, form);
    
    // Supprimer automatiquement après 5 secondes
    setTimeout(() => {
        alertDiv.classList.add('fade-out');
        setTimeout(() => {
            alertDiv.remove();
        }, 300);
    }, 5000);
}

// Afficher l'indicateur de chargement
function showLoading() {
    const loginBtn = document.querySelector('button[type="submit"]');
    loginBtn.disabled = true;
    loginBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Connexion en cours...';
}

// Masquer l'indicateur de chargement
function hideLoading() {
    const loginBtn = document.querySelector('button[type="submit"]');
    loginBtn.disabled = false;
    loginBtn.innerHTML = '<i class="fas fa-sign-in-alt me-2"></i>Connexion';
}

// Vérifier si l'utilisateur a déjà choisi le mode sombre
function checkDarkMode() {
    const isDarkMode = localStorage.getItem('darkMode') === 'true';
    if (isDarkMode) {
        document.body.classList.add('dark-mode');
    }
}

// Ajouter un bouton pour le mode sombre
function addDarkModeToggle() {
    const toggleButton = document.createElement('button');
    toggleButton.className = 'dark-mode-toggle';
    toggleButton.innerHTML = '<i class="fas fa-moon"></i>';
    toggleButton.title = 'Basculer le mode sombre';
    
    // Ajouter des styles
    const style = document.createElement('style');
    style.textContent = `
        .dark-mode-toggle {
            position: absolute;
            top: 20px;
            right: 20px;
            background: transparent;
            border: none;
            color: var(--secondary-color);
            font-size: 1.2rem;
            cursor: pointer;
            z-index: 10;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }
        
        .dark-mode-toggle:hover {
            background-color: rgba(0, 0, 0, 0.1);
        }
        
        .dark-mode .dark-mode-toggle {
            color: #e1e1e1;
        }
        
        .dark-mode .dark-mode-toggle:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .fade-out {
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .login-alert {
            animation: slideDown 0.4s ease;
            margin-bottom: 20px;
        }
        
        @keyframes slideDown {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    `;
    document.head.appendChild(style);
    
    // Mettre à jour l'icône si déjà en mode sombre
    if (document.body.classList.contains('dark-mode')) {
        toggleButton.innerHTML = '<i class="fas fa-sun"></i>';
    }
    
    // Ajouter l'événement de bascule
    toggleButton.addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
        const isDark = document.body.classList.contains('dark-mode');
        
        // Mettre à jour l'icône
        this.innerHTML = isDark ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
        
        // Enregistrer la préférence
        localStorage.setItem('darkMode', isDark);
    });
    
    // Ajouter au document
    document.querySelector('.login-form-container').appendChild(toggleButton);
}

// Animer l'apparition des éléments
function animateElements() {
    const elements = [
        document.querySelector('.logo-container'),
        document.querySelector('h2'),
        document.querySelector('h5'),
        ...document.querySelectorAll('.form-floating'),
        document.querySelector('.d-flex.justify-content-between'),
        document.querySelector('button[type="submit"]'),
        document.querySelector('.social-login'),
        document.querySelector('.text-center.mt-4')
    ];
    
    elements.forEach((element, index) => {
        if (element) {
            element.style.opacity = '0';
            element.style.transform = 'translateY(20px)';
            element.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            
            setTimeout(() => {
                element.style.opacity = '1';
                element.style.transform = 'translateY(0)';
            }, 100 + (index * 100));
        }
    });
}

// Vérifier si un utilisateur a été enregistré précédemment
document.addEventListener('DOMContentLoaded', function() {
    const rememberedUser = localStorage.getItem('rememberedUser');
    if (rememberedUser) {
        document.getElementById('email').value = rememberedUser;
        document.getElementById('rememberMe').checked = true;
    }
    
    // Animation de fond pour la partie droite
    animateBackground();
});

// Animation subtile de l'arrière-plan
function animateBackground() {
    const style = document.createElement('style');
    style.textContent = `
        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        
        .login-image-container {
            background-size: 200% 200%;
            animation: gradientAnimation 15s ease infinite;
        }
    `;
    document.head.appendChild(style);
}

// Détecter appui sur la touche Entrée
document.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && document.activeElement.tagName !== 'BUTTON') {
        e.preventDefault();
        document.querySelector('button[type="submit"]').click();
    }
});

// Afficher un message d'aide quand on clique sur "Mot de passe oublié"
document.addEventListener('DOMContentLoaded', function() {
    const forgotPassword = document.querySelector('.forgot-password');
    
    if (forgotPassword) {
        forgotPassword.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Créer une modal Bootstrap
            const modalHTML = `
                <div class="modal fade" id="forgotPasswordModal" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Réinitialisation du mot de passe</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p>Veuillez entrer votre adresse email. Un lien de réinitialisation vous sera envoyé.</p>
                                <div class="form-floating">
                                    <input type="email" class="form-control" id="resetEmail" placeholder="nom@exemple.com">
                                    <label for="resetEmail">Adresse email</label>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                                <button type="button" class="btn btn-primary" id="sendResetLink">Envoyer le lien</button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            // Ajouter la modal au document
            document.body.insertAdjacentHTML('beforeend', modalHTML);
            
            // Initialiser et afficher la modal
            const modal = new bootstrap.Modal(document.getElementById('forgotPasswordModal'));
            modal.show();
            
            // Gérer l'envoi du lien
            document.getElementById('sendResetLink').addEventListener('click', function() {
                const email = document.getElementById('resetEmail').value;
                if (!email) {
                    alert('Veuillez entrer votre adresse email.');
                    return;
                }
                
                // Simuler l'envoi
                this.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Envoi en cours...';
                this.disabled = true;
                
                setTimeout(() => {
                    modal.hide();
                    
                    // Afficher un message de confirmation
                    setTimeout(() => {
                        showAlert('Un email de réinitialisation a été envoyé à ' + email, 'success');
                    }, 500);
                    
                    // Supprimer la modal du DOM
                    setTimeout(() => {
                        document.getElementById('forgotPasswordModal').remove();
                    }, 1000);
                }, 2000);
            });
        });
    }
});